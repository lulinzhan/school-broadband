﻿[CmdletBinding()]
param([switch]$Silent, [switch]$Pause)

$LocalRoot = $env:LOCALAPPDATA
if ([string]::IsNullOrWhiteSpace($LocalRoot)) { $LocalRoot = [Environment]::GetFolderPath('LocalApplicationData') }
if ([string]::IsNullOrWhiteSpace($LocalRoot)) { $LocalRoot = Join-Path $env:USERPROFILE 'AppData\Local' }
$InstallTo = Join-Path $LocalRoot 'Programs\SchoolBroadband'
$DataDir   = Join-Path $LocalRoot 'SchoolBroadband'

Write-Host ''
Write-Host '  卸载 宽带管家'
Write-Host ''
if (-not $Silent) {
    $ans = Read-Host '  确认卸载？(y/N)'
    if ($ans -notmatch '^[yY]') { Write-Host '  已取消。'; exit 1 }
}

$targets = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) '宽带管家.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '宽带管家\宽带管家.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '宽带管家'),
    # 开机自连的启动项：必须一起删，否则每次登录都会去拽已经不存在的程序
    (Join-Path ([Environment]::GetFolderPath('Startup')) '宽带管家-开机自动连接.lnk'),
    # 老版本（桌面放两个图标那版）留下的残留，一并清掉
    (Join-Path ([Environment]::GetFolderPath('Desktop')) '学校宽带.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Desktop')) '宽带设置.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) '一键宽带'),
    (Join-Path ([Environment]::GetFolderPath('Startup')) '一键宽带-自动连接.lnk')
)
foreach ($t in $targets) {
    if (Test-Path -LiteralPath $t) {
        Remove-Item -LiteralPath $t -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host ("  已删除 {0}" -f $t)
    }
}

# 开机计划任务也得注销，否则卸载之后每次登录仍会去拽已经不存在的程序。
# 「掉线自动重连」是同一回事：留着它，卸载完它还会被叫醒去调已经删掉的脚本。
foreach ($tn in @('宽带管家-开机自动连接', '一键宽带-开机自动连接',
                  '宽带管家-掉线自动重连', '一键宽带-掉线自动重连')) {
    try {
        $st = Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue
        if ($st) {
            Unregister-ScheduledTask -TaskName $tn -Confirm:$false -ErrorAction Stop
            Write-Host ("  已注销计划任务 {0}" -f $tn)
        }
    } catch {
        Write-Host ("  注销计划任务 {0} 失败：{1}" -f $tn, $_.Exception.Message)
    }
}

if (Test-Path -LiteralPath $InstallTo) {
    Remove-Item -LiteralPath $InstallTo -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host '  已删除程序文件'
}

Write-Host ''
Write-Host ("  已保存的账号密码保留在：{0}" -f $DataDir)
Write-Host '  如需连凭据一起删除，手动删掉该文件夹即可。'
Write-Host ''
# -Pause 是给界面上的「卸载」按钮用的：界面已经弹框确认过了，不需要再问一次 y/N，
# 但脚本自己的输出（删了哪些东西）得让用户看清，所以还留一个「按回车退出」。
if (-not $Silent -or $Pause) { Read-Host '  按回车退出' | Out-Null }