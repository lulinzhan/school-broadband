@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
set rc=%errorlevel%
if not "%rc%"=="0" echo Installer exited with code %rc%.
endlocal