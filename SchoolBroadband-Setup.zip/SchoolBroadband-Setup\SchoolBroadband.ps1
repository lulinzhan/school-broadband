﻿<#
  宽带管家 —— 开机自动连接 + 一键连接（可以管多条宽带）
  ==================================================================
  目标：
    · 开机登录后，把「开了自启」的宽带一条条试过去，连上就停；
    · 一条都连不上时，打开系统的宽带拨号窗口，让你手动接一下；
    · 开着「掉线自动重连」时：掉线几秒内、睡眠唤醒几秒内自动接回来 —— 而且不只问
      「连没连上」，还会真的往外连一下试试通不通，专门抓「显示已连接其实是死的」那种假连接；
    · 双击桌面图标 -> 打开管理界面：添加/删除宽带、给每条单独开关开机自启、
      改账号密码、立即连接。

  数据文件（都在 %LOCALAPPDATA%\SchoolBroadband\）：
    profiles.json   宽带清单（每条含 账号 / 加密密码 / 自启开关），顺序即尝试顺序
    last-run.log    运行日志（连不上时看这里）

  密码安全：
    每条宽带的密码都用 Windows DPAPI 加密（ConvertFrom-SecureString，不带 -Key），
    只有「当前 Windows 用户 + 本机」能解开；拷到别的电脑或别的账户都解不开。

  为什么开机自连用「启动」文件夹、掉线重连却用计划任务：
    「登录时」计划任务要管理员权限；启动文件夹对当前用户即可，用户还能自己在文件夹里
    看见、随时删掉，卸载也好清理 —— 所以开机自连走启动文件夹。
    而「过一会儿看一眼有没有掉线」这件事没法靠文件夹做，只能用计划任务。它注册的是
    当前用户自己的任务（不是以最高权限运行），标准用户就能建，不用弹 UAC。
    代价是计划任务在「登录后」才触发，不是开机瞬间——Windows 没登录时本来也建立不了
    拨号连接。

  可迁移性：
    只依赖 Windows 自带组件（powershell 5.1 / rasdial / rasphone / WScript）。
    连接名从电话簿读取，不用改脚本；密码 DPAPI 绑定当前用户+本机，换机必须重输。
    桌面图标里存的是绝对路径，换机需要重建（或直接把 .vbs 拖到桌面）。
#>

[CmdletBinding()]
param(
    # ---- 连接 ----
    # 手动连接：按顺序尝试全部宽带（开了自启的排前面）
    [switch]$Connect,
    # 开机自连：只尝试开了自启的宽带，先等网络就绪
    [switch]$AutoConnect,
    # 开机后最多等这么多秒等网卡就绪（一旦就绪立刻开拨，不会白等满）
    [int]$WarmupSec = 15,
    # 每条宽带最多试几次
    [int]$RetryPerProfile = 3,
    # 两次尝试之间隔几秒
    [int]$RetryIntervalSec = 3,
    # 单次拨号最多等几秒（拨通通常 3~8 秒就返回，这个值只影响失败时白等多久）
    [int]$SilentTimeoutSec = 20,
    # 一条都连不上时，打开系统的宽带拨号窗口
    [switch]$FallbackToUi,
    # 只查状态，不拨号
    [switch]$Status,

    # ---- 配置管理（由设置界面调用，都不拨号）----
    [switch]$ListProfiles,
    [switch]$ListConnections,
    # 按 profiles.json 里的自启勾选，重建「启动」文件夹里的快捷方式（安装器装完叫一次）
    [switch]$SyncStartup,
    # 极速启动：把「开机自动连接」注册成 Windows 计划任务。任务计划服务在登录那一刻
    # 就把它拉起来，不像「启动」文件夹要等 explorer 把桌面、任务栏、托盘都忙完，
    # 实测通常能早十几秒。注册成「当前用户登录时触发」的形式，标准权限就够，不弹 UAC。
    [switch]$FastStartOn,
    [switch]$FastStartOff,
    [switch]$FastStartStatus,
    # 掉线自动重连：挂「掉线 / 拨号断开 / 睡眠唤醒 / 登录」几类系统事件，再加一条每 15
    # 分钟兜底的计划任务。断线后几秒就自己拨回来，还能救「显示已连接、其实早就死了」
    # 那种假连接。同样不需要管理员。
    [switch]$ReconnectOn,
    [switch]$ReconnectOff,
    [switch]$ReconnectStatus,
    # 体检入口（给计划任务调用）：先确认连接是真通的，不通才重拨
    [switch]$Reconnect,
    [string]$AddProfile,
    # 显示名（可选）：列表里显示的名字，留空就直接用连接名
    [string]$ProfileLabel,
    [string]$RemoveProfile,
    [string]$SetProfile,
    [string]$AutoOn,
    [string]$AutoOff,
    [string]$MoveUp,
    [string]$MoveDown,
    [string]$Account,
    [string]$Password,
    [switch]$AutoStart
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

# %LOCALAPPDATA% 正常情况下一定有；但在受限账户、被安全软件/沙箱裁剪过的环境里
# 它可能是空的，那时 Join-Path 抛出的「参数为空」异常完全看不出真实原因，
# 所以这里自己兜一层：拿不到就退到 Shell API，再退到用户主目录。
function Get-DataRoot {
    $cands = @(
        $env:LOCALAPPDATA,
        [Environment]::GetFolderPath('LocalApplicationData'),
        $(if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) { Join-Path $env:USERPROFILE 'AppData\Local' }),
        $env:TEMP
    )
    foreach ($c in $cands) {
        if (-not [string]::IsNullOrWhiteSpace($c)) { return $c }
    }
    return (Get-Location).Path
}
$StoreDir     = Join-Path (Get-DataRoot) 'SchoolBroadband'
$ProfilesFile = Join-Path $StoreDir 'profiles.json'
$LegacyFile   = Join-Path $StoreDir 'settings.json'
$LogFile      = Join-Path $StoreDir 'last-run.log'
$AppTag       = 'broadband-butler'
$LegacyTag    = 'school-broadband-oneclick'
$StartupLink  = '宽带管家-开机自动连接.lnk'
# 计划任务名：由任务计划服务在登录事件发生时立刻触发，比「启动」文件夹早
$StartupTaskName   = '宽带管家-开机自动连接'
$ReconnectTaskName = '宽带管家-掉线自动重连'
# 体检探针：国内公共 DNS 的 53 端口。只用来判断「对端还在不在」，不解析任何域名。
# 用 TCP 而不是 ICMP ping，原因见 Test-Healthy 里的注释。按顺序试，任意一个通就算通。
$ProbeTargets   = @(
    @('223.5.5.5',      53),   # 阿里 DNS
    @('114.114.114.114', 53)   # 114 DNS
)
$ProbeTimeoutMs = 2000

$Rasdial  = Join-Path $env:SystemRoot 'System32\rasdial.exe'
$Rasphone = Join-Path $env:SystemRoot 'System32\rasphone.exe'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Write-Host $line
    try {
        if (-not (Test-Path $StoreDir)) { New-Item -ItemType Directory -Path $StoreDir -Force | Out-Null }
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    } catch {}
}

# ---------------------------------------------------------------- 电话簿
# rasphone.pbk 在 Win10/11 上是 UTF-8（通常无 BOM）。按系统 ANSI 硬读会把
# 「宽带连接 3」变成「瀹藉甫杩炴帴 3」，拿这个乱码名字去 rasdial 必然拨号失败。
# throwOnInvalidBytes=true：能解码就是 UTF-8，解不了才抛异常、回退到 ANSI。
function Get-PbkEntries {
    $pbks = @(
        (Join-Path $env:APPDATA 'Microsoft\Network\Connections\Pbk\rasphone.pbk'),
        (Join-Path $env:ProgramData 'Microsoft\Network\Connections\Pbk\rasphone.pbk')
    )
    foreach ($f in $pbks) {
        if (-not (Test-Path -LiteralPath $f)) { continue }
        $text = $null
        try   { $text = [IO.File]::ReadAllText($f, (New-Object Text.UTF8Encoding($false, $true))) }
        catch { $text = [IO.File]::ReadAllText($f, [Text.Encoding]::GetEncoding(936)) }
        foreach ($line in ($text -split "`r?`n")) {
            $t = $line.Trim()
            if ($t.Length -gt 2 -and $t.StartsWith('[') -and $t.EndsWith(']')) {
                [pscustomobject]@{ Name = $t.Substring(1, $t.Length - 2); File = $f }
            }
        }
    }
}

function Get-PbkNames { return @(Get-PbkEntries | Select-Object -ExpandProperty Name -Unique) }

# ---------------------------------------------------------------- 配置读写
function ConvertFrom-LegacySettings {
    if (-not (Test-Path -LiteralPath $LegacyFile)) { return $null }
    try { $s = Get-Content -LiteralPath $LegacyFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return $null }
    if (-not $s) { return $null }
    if ($s._tag -ne $LegacyTag) { return $null }
    if ([string]::IsNullOrWhiteSpace($s.connectionName)) { return $null }
    return [pscustomobject]@{
        name        = [string]$s.connectionName
        label       = [string]$s.connectionName
        account     = [string]$s.account
        passwordEnc = [string]$s.passwordEnc
        autoStart   = $true
    }
}

# 写完立刻读回来逐条核对。写进去不等于写对了：安全软件有的只拦「改」不拦「建」，
# 有的先让写、事后回滚，还有的只吞掉一部分字节。所以必须重新从磁盘读一遍，
# 比条数、比账号、比密码密文，并且真的解一次密文。
function Assert-ProfilesRoundTrip {
    param($List)
    $expect = @($List)
    $back = @()
    try {
        $obj = (Get-Content -LiteralPath $ProfilesFile -Raw -Encoding UTF8) | ConvertFrom-Json
        $back = @($obj.profiles)
    } catch {
        Write-Log "配置写进去以后读不回来：$($_.Exception.Message)" 'ERROR'
        throw 'profiles.json 读不回来'
    }
    if ($back.Count -ne $expect.Count) {
        Write-Log "配置核对失败：磁盘上有 $($back.Count) 条，本该有 $($expect.Count) 条。" 'ERROR'
        throw 'profiles.json 条数对不上'
    }
    foreach ($p in $expect) {
        $b = $null
        foreach ($q in $back) { if ([string]$q.name -eq [string]$p.name) { $b = $q; break } }
        if (-not $b) {
            Write-Log "配置核对失败：磁盘上找不到「$($p.label)」。" 'ERROR'
            throw 'profiles.json 缺条目'
        }
        if (-not [string]::IsNullOrWhiteSpace($p.account) -and [string]$b.account -ne [string]$p.account) {
            Write-Log "配置核对失败：「$($p.label)」的账号没落盘（磁盘上是「$([string]$b.account)」）。" 'ERROR'
            throw '账号没落盘'
        }
        if (-not [string]::IsNullOrEmpty($p.passwordEnc) -and [string]::IsNullOrEmpty($b.passwordEnc)) {
            Write-Log "配置核对失败：「$($p.label)」的密码没能落盘 —— 就是这么丢的。" 'ERROR'
            throw '密码没落盘'
        }
        if (-not [string]::IsNullOrEmpty($b.passwordEnc)) {
            # 这里刻意不调 ConvertTo-PlainPassword：那个函数定义在文件后半段，
            # 而 Write-Profiles 在 Read-Profiles 里就会被调用，那时它还没注册。
            try {
                $sec = ConvertTo-SecureString ([string]$b.passwordEnc)
                $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
                [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            } catch {
                Write-Log "配置核对失败：「$($p.label)」的密码存下来了但解不开（换过 Windows 用户或重装过系统？），得重新输一次。" 'ERROR'
                throw '密文解不开'
            }
        }
    }
}

function Write-Profiles {
    param($List)
    try {
        if (-not (Test-Path $StoreDir)) { New-Item -ItemType Directory -Path $StoreDir -Force | Out-Null }
        $obj = [ordered]@{ _tag = $AppTag; version = 2; profiles = @($List) }
        ($obj | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $ProfilesFile -Encoding UTF8
    } catch {
        # 这一步以前是裸的：异常直接往外抛，而「已添加」那句日志早就打出去了，
        # 用户以为配好了，盘上其实什么都没有 —— 开机自然连不上，还找不到原因。
        Write-Log ("写配置失败，连 $ProfilesFile 都写不进去。`r`n原因：$($_.Exception.Message)`r`n" +
                   "八成是安全软件（火绒 / 360 / 电脑管家 / Defender）拦了往 $StoreDir 写文件。" +
                   "把「宽带管家」加进它的信任区，或者临时退出它，再重新添加一次。") 'ERROR'
        throw
    }
    Assert-ProfilesRoundTrip -List $List
}

function Read-Profiles {
    $list = New-Object Collections.ArrayList
    if (Test-Path -LiteralPath $ProfilesFile) {
        try {
            $obj = (Get-Content -LiteralPath $ProfilesFile -Raw -Encoding UTF8) | ConvertFrom-Json
            foreach ($p in @($obj.profiles)) {
                if ($p -and -not [string]::IsNullOrWhiteSpace($p.name)) {
                    [void]$list.Add([pscustomobject]@{
                        name        = [string]$p.name
                        label       = $(if ([string]::IsNullOrWhiteSpace($p.label)) { [string]$p.name } else { [string]$p.label })
                        account     = [string]$p.account
                        passwordEnc = [string]$p.passwordEnc
                        autoStart   = [bool]$p.autoStart
                    })
                }
            }
        } catch {
            Write-Log "配置文件读不出来，已忽略：$($_.Exception.Message)" 'WARN'
        }
    }
    if ($list.Count -eq 0) {
        $mig = ConvertFrom-LegacySettings
        if ($mig) {
            [void]$list.Add($mig)
            Write-Profiles -List $list
            Write-Log "已把旧的单条宽带配置迁移过来：$($mig.name)（开机自启保持开启）" 'OK'
        }
    }
    return ,$list
}

function Find-Profile {
    param($List, [string]$Name)
    foreach ($p in $List) { if ($p.name -eq $Name) { return $p } }
    return $null
}

function ConvertTo-PlainPassword {
    param([string]$Encrypted)
    if ([string]::IsNullOrEmpty($Encrypted)) { return '' }
    $sec = ConvertTo-SecureString $Encrypted
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function Protect-Password {
    param([string]$Plain)
    $sec = ConvertTo-SecureString -String $Plain -AsPlainText -Force
    return ($sec | ConvertFrom-SecureString)   # 不带 -Key 即 DPAPI
}

function Get-ProfileCredential {
    param($Profile)
    if ([string]::IsNullOrWhiteSpace($Profile.account)) { return $null }
    try {
        $plain = ConvertTo-PlainPassword $Profile.passwordEnc
    } catch {
        Write-Log "「$($Profile.label)」保存的密码解不开（可能换了 Windows 用户或重装过系统），需要重新输一次。" 'WARN'
        return $null
    }
    return [pscustomobject]@{ User = [string]$Profile.account; Pass = $plain }
}

# ---------------------------------------------------------------- 开机启动项
# 只要还有任意一条宽带开着自启，就在「启动」文件夹放一个快捷方式；
# 全部关掉就把快捷方式删掉。这样「开机自连」的总开关就是这些分开关的逻辑或。
function Get-StartupLinkPath {
    $startup = [Environment]::GetFolderPath('Startup')
    if ([string]::IsNullOrEmpty($startup)) { return $null }
    return (Join-Path $startup $StartupLink)
}

function Get-LauncherVbs {
    foreach ($c in @('SchoolBroadband.vbs', '一键宽带.vbs', '宽带管家.vbs')) {
        $p = Join-Path $PSScriptRoot $c
        if (Test-Path -LiteralPath $p) { return $p }
    }
    $any = @(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.vbs' -ErrorAction SilentlyContinue |
             Sort-Object Name | Select-Object -First 1)
    if ($any.Count -gt 0) { return $any[0].FullName }
    return $null
}

# ---------------------------------------------------------------- 开机计划任务
# 「启动」文件夹要等资源管理器完全加载完才开始执行，登录后往往要十几秒才轮到；
# 计划任务由任务计划服务在登录事件发生时立刻拉起，通常能早十几秒。
#
# 【踩过的坑】早先这里写着「注册计划任务要管理员权限」，那是错的。真正的原因是
# New-ScheduledTaskTrigger -AtLogOn **不带 -User** 时含义是「任何用户登录」，
# 这种触发器只有管理员建得出来，标准用户会直接吃一个 Access is denied。
# 实测（Windows 11，标准用户 LULU\33791）：
#     -AtLogOn                  -> Access is denied（HRESULT 0x80070005）
#     -AtLogOn -User LULU\33791 -> 成功，两个触发器都能建出来
#     schtasks /sc onlogon      -> 同样 Access is denied（它也是「任何用户」）
# 所以下面一律带上 -User，标准用户不用管理员也能建。
function Get-CurrentUserId {
    # 计划任务的 -User 要「域\用户名」这种写法；只有机器名没域名的机器上
    # USERDOMAIN 就是机器名，拼出来一样能用。
    if ([string]::IsNullOrWhiteSpace($env:USERDOMAIN)) { return $env:USERNAME }
    return ("$env:USERDOMAIN\$env:USERNAME")
}

function Sync-StartupTask {
    param([bool]$Enable, [string]$Vbs)
    try {
        $existing = Get-ScheduledTask -TaskName $StartupTaskName -ErrorAction SilentlyContinue
        if (-not $Enable) {
            if ($existing) {
                Unregister-ScheduledTask -TaskName $StartupTaskName -Confirm:$false -ErrorAction Stop
                Write-Log '已移除开机计划任务。' 'OK'
            }
            return $true
        }
        if (-not $Vbs) { return $false }
        $action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\wscript.exe') `
                                          -Argument ('"' + $Vbs + '" -AutoConnect') `
                                          -WorkingDirectory $PSScriptRoot
        $trigger  = New-ScheduledTaskTrigger -AtLogOn -User (Get-CurrentUserId)
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                                                 -StartWhenAvailable -MultipleInstances IgnoreNew `
                                                 -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
        Register-ScheduledTask -TaskName $StartupTaskName -Action $action -Trigger $trigger `
                               -Settings $settings -Force -ErrorAction Stop | Out-Null
        Write-Log '开机计划任务已就绪（登录后立刻触发，比「启动」文件夹更早）。' 'OK'
        return $true
    } catch {
        Write-Log "计划任务方式用不了（$($_.Exception.Message.Trim())），继续用「启动」文件夹。" 'WARN'
        if ("$($_.Exception.Message)" -match 'denied|拒绝') {
            $exists = $false
            try { $exists = [bool](Get-ScheduledTask -TaskName $StartupTaskName -ErrorAction SilentlyContinue) } catch { }
            if ($exists) {
                Write-Log '同名任务已经在了，而且不是当前用户建的（多半是以前用管理员身份建过一次），' 'WARN'
                Write-Log '标准权限删不掉也改不动它。要清掉的话：开始菜单搜「任务计划程序」，' 'WARN'
                Write-Log '在「任务计划程序库」里找到「宽带管家-开机自动连接」，右键删除（会弹一次 UAC），' 'WARN'
                Write-Log '清掉之后这个开关就能正常用了。' 'WARN'
            } else {
                Write-Log '被系统拒绝了。通常是有安全软件在拦计划任务，把「宽带管家」加进信任区再试。' 'WARN'
            }
        }
        return $false
    }
}

# ---------------------------------------------------------------- 掉线重连计划任务
# 触发器一共五个。前三个是「某条系统事件一发生就立刻体检」，后两个负责「没人叫的时候
# 也得偶尔看一眼」：
#   1) 拨号连接被 RasMan 断开（事件 System / RasMan / ID 20268）——**主力快线**，等 3 秒
#   2) 网络已断开（事件 Microsoft-Windows-NetworkProfile/Operational / ID 10001）
#      ——比上面那条宽泛，等 20 秒，定位是「第二道机会」
#   3) 系统从睡眠 / 休眠唤醒（事件 System / Power-Troubleshooter / ID 1），等 6 秒
#   4) 登录后 1 分钟查一次（刚开机那会儿最容易是断的）
#   5) 每 15 分钟一次，兜住「一条事件都没记」的诡异掉线
# 【为什么非得挂掉线事件】最早只有第 5 条，也就是「最多等 15 分钟才有人管」。用户拔了
# 网线盯着屏幕看一两分钟，什么都不会发生 —— 在他看来这就是「这功能没实现」。实测断开
# 宽带的那一秒，系统立刻就写了上面 1、2 两条事件（同一秒），所以挂上去之后，掉线后
# 几秒就能接回来，而不是十几分钟。
# 【延迟为什么敢只留 3 秒】体检入口是幂等的：网络要是自己回来了，它跑起来只会写一句
# 「在线且通畅，什么都不用做」就退出，代价仅仅是启动一次进程。而 rasdial 拨号本身要
# 6 秒左右（PPPoE 协商 + 认证，压不动），把等待从 15 秒压到 3 秒，用户感知的恢复时间
# 就从 19 秒降到 10 秒上下 —— 这是整条链路上唯一能大幅压缩的一段。
# 平时它只是躺在任务库里，不占内存；被事件叫醒才起一个 wscript 跑一次就退。
# 造一个「某条系统事件发生时触发」的触发器。计划任务里没有现成选项，得自己拼一个
# CIM 实例当触发器用，并把筛选条件写成 XPath。建不起来就返回 $null，由调用方决定降级，
# 绝不因为一条边角触发器把整个任务注册搞失败。
function New-EventTrigger {
    param([string]$LogName, [string]$Provider, [int]$EventId, [string]$Delay)
    try {
        $cls = Get-CimClass -Namespace 'Root/Microsoft/Windows/TaskScheduler' `
                            -ClassName 'MSFT_TaskEventTrigger' -ErrorAction Stop
        $t = New-CimInstance -CimClass $cls -ClientOnly
        $t.Enabled      = $true
        $t.Delay        = $Delay
        # 【注意 EventID 的位置】它必须写在 System[...] 这一层，也就是 Provider[...] 的
        # **外面**：*[System[Provider[@Name="X"] and EventID=1]]
        # 一旦写成 Provider[@Name="X" and EventID=1]，含义就变成「要求 Provider 元素自带
        # 一个 EventID 属性」—— 语法上不成立，这条触发器会永远静默、一条事件都匹配不到，
        # 而注册却会成功、日志还会说「已就绪」。这个坑踩过一次，所以下面加了一道自检。
        $t.Subscription = '<QueryList><Query Id="0" Path="' + $LogName + '">' +
                          '<Select Path="' + $LogName + '">' +
                          '*[System[Provider[@Name="' + $Provider + '"] and EventID=' + $EventId + ']]' +
                          '</Select></Query></QueryList>'
        # 自检：把查询式交给事件日志解析器真解析一遍。写错了就在这儿抛异常，而不是等到
        # 「掉线了却没人管」的时候才发现。没有匹配事件时 ReadEvent() 返回 $null，不算错。
        $q = New-Object System.Diagnostics.Eventing.Reader.EventLogQuery(
                 $LogName, [System.Diagnostics.Eventing.Reader.PathType]::LogName, $t.Subscription)
        $rdr = New-Object System.Diagnostics.Eventing.Reader.EventLogReader($q)
        [void]$rdr.ReadEvent()
        $rdr.Dispose()
        return $t
    } catch {
        Write-Log "建「$Provider 事件 $EventId」触发器没成功：$($_.Exception.Message)" 'WARN'
        return $null
    }
}

function Sync-ReconnectTask {
    param([bool]$Enable, [string]$Vbs)
    # 这里刻意**不做管理员检查**：注册一个「以当前用户身份、按需运行」的计划任务，
    # 标准用户本来就有权做；一上来就要求管理员，只会白白弹一次 UAC 把人吓一跳。
    # 万一真被拒绝了，下面的 catch 会把 Windows 的原话写进日志，比我们自己猜的准。
    try {
        $existing = Get-ScheduledTask -TaskName $ReconnectTaskName -ErrorAction SilentlyContinue
        if (-not $Enable) {
            if ($existing) {
                Unregister-ScheduledTask -TaskName $ReconnectTaskName -Confirm:$false -ErrorAction Stop
                Write-Log '已关闭掉线自动重连。' 'OK'
            }
            return $true
        }
        if (-not $Vbs) { return $false }
        $action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\wscript.exe') `
                                          -Argument ('"' + $Vbs + '" -Reconnect') `
                                          -WorkingDirectory $PSScriptRoot

        # 触发器四之一：登录后 1 分钟先查一次（刚开机那会儿最容易是断的）。
        # -User 必须带上，否则等于「任何用户登录」，标准用户会被 Access is denied 挡掉。
        $tLogon = New-ScheduledTaskTrigger -AtLogOn -User (Get-CurrentUserId)
        $tLogon.Delay = 'PT1M'

        # 触发器四之二（兜底轮询）：注册完 1 分钟起，每 15 分钟一次，连跑 10 年。
        # 【为什么不用给登录触发器挂 Repetition】那样写的话，「重复」要等登录触发器先
        # 命中一次才开始计时 —— 而这台机器上任务是在登录之后才注册的，于是刚装好、
        # 刚改完开关的那几个小时里，轮询根本没在走（实测 NextRunTime 是空的）。
        # 用一条独立的 -Once 触发器，注册完立刻起算，跟登录没关系，也好验证。
        $tPoll = New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(1)) `
                                          -RepetitionInterval (New-TimeSpan -Minutes 15) `
                                          -RepetitionDuration (New-TimeSpan -Days 3650)
        $tPoll.Repetition.StopAtDurationEnd = $false

        # 触发器一：拨号连接被 RasMan 断开（事件 20268）。这是**主力快线** —— 它专记
        # PPPoE 会话被拆掉，最精准，所以只等 3 秒就动手。
        # 【为什么不担心「拨太早白拨一次」】体检入口是幂等的：网络要是自己回来了，
        # 它跑起来只会写一句「在线且通畅，什么都不用做」就退出，代价只是启动一次进程。
        # 万一 3 秒时系统还没收拾干净，Invoke-ConnectAll 自己还会重试 3 次（间隔 3 秒）。
        $tDropPpp = New-EventTrigger -LogName 'System' -Provider 'RasMan' `
                                     -EventId 20268 -Delay 'PT3S'

        # 触发器二：网络配置层面的「网络已断开」（10001）。它比上面那条宽泛（WiFi / 网线
        # 断了也会发），所以留 20 秒 —— 定位是**第二道机会**：万一 3 秒那次没接上，
        # 这里再来一次。顺利接上的情况下它只是空跑一遍然后退出。
        $tDropProfile = New-EventTrigger -LogName 'Microsoft-Windows-NetworkProfile/Operational' `
                                         -Provider 'Microsoft-Windows-NetworkProfile' `
                                         -EventId 10001 -Delay 'PT20S'

        # 触发器三：从睡眠 / 休眠唤醒。Power-Troubleshooter 的 ID 1 是系统每次唤醒都会
        # 写进去的一条。唤醒后网卡通常几秒内就绪，6 秒够用；真没就绪还有内部重试兜着。
        $tWake = New-EventTrigger -LogName 'System' -Provider 'Power-Troubleshooter' `
                                  -EventId 1 -Delay 'PT6S'

        $triggers = @($tLogon, $tPoll)
        foreach ($t in @($tDropProfile, $tDropPpp, $tWake)) { if ($t) { $triggers += $t } }

        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                                                 -StartWhenAvailable -MultipleInstances IgnoreNew `
                                                 -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
        Register-ScheduledTask -TaskName $ReconnectTaskName -Action $action -Trigger $triggers `
                               -Settings $settings -Force -ErrorAction Stop | Out-Null
        if ($tDropProfile -and $tDropPpp) {
            Write-Log '掉线自动重连已就绪（掉线后十秒上下接回来；睡眠唤醒后八秒上下；另有每 15 分钟兜底体检）。' 'OK'
        } else {
            $miss = @()
            if (-not $tDropProfile) { $miss += '网络断开事件' }
            if (-not $tDropPpp)     { $miss += '拨号断开事件' }
            if (-not $tWake)        { $miss += '唤醒事件' }
            Write-Log "掉线自动重连已就绪，但少挂了：$($miss -join '、')。只靠每 15 分钟的兜底体检，接回来会慢很多。" 'WARN'
        }
        return $true
    } catch {
        Write-Log "注册掉线重连任务失败：$($_.Exception.Message)" 'ERROR'
        if ("$($_.Exception.Message)" -match 'denied|拒绝') {
            Write-Log '被系统拒绝了。这一项要在计划任务里注册「当前用户登录时触发」，' 'WARN'
            Write-Log '标准用户本来就有权建；报「拒绝访问」通常是安全软件在拦计划任务，' 'WARN'
            Write-Log '把「宽带管家」加进它的信任区再试一次。' 'WARN'
        } else {
            Write-Log '这一项是靠计划任务实现的，注册不上就只剩开机自连那一层保障了。' 'WARN'
        }
        return $false
    }
}

function Sync-StartupLink {
    param($List)
    $link = Get-StartupLinkPath
    if (-not $link) { Write-Log '找不到「启动」文件夹。' 'WARN'; return }
    $auto = @($List | Where-Object { $_.autoStart })
    if ($auto.Count -eq 0) {
        if (Test-Path -LiteralPath $link) {
            try { Remove-Item -LiteralPath $link -Force; Write-Log '所有宽带的自启都关了，已移除开机启动项。' 'OK' }
            catch { Write-Log "移除开机启动项失败：$($_.Exception.Message)" 'ERROR' }
        }
        return
    }
    $vbs = Get-LauncherVbs
    if (-not $vbs) { Write-Log '同目录下找不到启动器 .vbs，无法设置开机启动项。' 'ERROR'; return }
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($link)
        $sc.TargetPath       = Join-Path $env:SystemRoot 'System32\wscript.exe'
        $sc.Arguments        = '"' + $vbs + '" -AutoConnect'
        $sc.WorkingDirectory = $PSScriptRoot
        $sc.IconLocation     = (Join-Path $env:SystemRoot 'System32\SHELL32.dll') + ',14'
        $sc.Description      = '登录后自动连接宽带'
        $sc.Save()
        Write-Log ("开机启动项已就绪（{0} 条宽带会在登录后依次尝试）：{1}" -f $auto.Count, $link) 'OK'
    } catch {
        Write-Log "写开机启动项失败：$($_.Exception.Message)" 'ERROR'
    }
    # 注意：这里**不**注册计划任务。要不要再加那道更早的入口，由用户在界面上的
    # 「极速启动」开关决定（-FastStartOn / -FastStartOff），默认不开。
}

# ---------------------------------------------------------------- 连接状态
# rasdial 的输出是系统 ANSI 编码（中文系统即 GBK）。用默认编码读会把「已连接」
# 读成乱码，于是下面永远匹配不到，脚本就会以为没连上而反复重拨。
function Get-RasdialOutput {
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName               = $Rasdial
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.CreateNoWindow         = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::GetEncoding(936)
    $psi.StandardErrorEncoding  = [Text.Encoding]::GetEncoding(936)
    $p = [Diagnostics.Process]::Start($psi)
    $text = ($p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd())
    $p.WaitForExit()
    return $text.Trim()
}

function Get-CurrentConnectionNames {
    $names = @()

    # 【踩过的坑】这里以前是拿 rasdial 的输出做正则匹配，而且写的是
    #     '^(?:已连接|Connected to)\s+(.+)$'
    # —— 假定「已连接」和连接名印在同一行。可 rasdial 实际是分两行印的：
    #       已连接
    #       宽带连接
    #       命令已完成。
    # 结果一条都匹配不上（更早的版本还错写成 $Matches[2]，那更是永远为空），
    # 于是 Test-Connected 永远返回「没连上」：状态栏一直显示「未连接」，
    # 掉线体检每 15 分钟白拨一次，还额外打一条吓人的 WARN。
    #
    # 现在改成不解析文字：直接问系统有哪些网络接口是「Ppp 类型且已启用」。
    # 名字和状态都是结构化数据，不受系统语言、控制台编码、rasdial 排版变化影响，
    # 也不用再起一个子进程。实测拨通后能拿到 Name = 宽带连接。
    try {
        foreach ($ni in [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
            if ($ni.NetworkInterfaceType -eq 'Ppp' -and $ni.OperationalStatus.ToString() -eq 'Up') {
                $names += $ni.Name
            }
        }
    } catch { }
    if (@($names).Count -gt 0) { return $names }

    # 退路：万一上面这条路取不到（极老的系统、网卡驱动异常），再解析 rasdial。
    # 分两行和挤在一行两种排版都认；不认识的段落一律不算连接名。
    $inConnected = $false
    foreach ($line in ((Get-RasdialOutput) -split "`r?`n")) {
        $t = $line.Trim()
        if (-not $t) { continue }
        if ($t -match '^(?:已连接|Connected to)\s+(.+)$') { $names += $Matches[1].Trim(); continue }
        if ($t -match '^(?:已连接|Connected to)$') { $inConnected = $true;  continue }
        if ($t -match '^(?:没有连接|未连接|No connections|Disconnected)$') { $inConnected = $false; continue }
        if ($t -match '^(?:命令已完成|Command completed)') { $inConnected = $false; continue }
        if ($inConnected) { $names += $t }
    }
    return $names
}

# ---------------------------------------------------------------- 等网卡就绪
# 开机自连时网卡/PPPoE 端口要几秒才就绪，但傻等固定秒数太浪费——大多数机器
# 1~2 秒内就好了。这里改成轮询：只要出现任何一个「已启用且已连接」的物理接口
# 就立刻返回，不再等。返回实际等待的秒数；-1 表示等到上限还没就绪。
function Wait-NetworkReady {
    param([int]$MaxSec = 15)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($true) {
        try {
            $up = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
                  Where-Object {
                      $_.NetworkInterfaceType -ne 'Loopback' -and
                      $_.OperationalStatus.ToString() -eq 'Up'
                  }
            if ($up) { return [math]::Round($sw.Elapsed.TotalSeconds, 1) }
        } catch { }
        if ($sw.Elapsed.TotalSeconds -ge $MaxSec) { return -1 }
        Start-Sleep -Milliseconds 250
    }
}

function Test-Connected {
    param([string]$Name)
    $want = ($Name -replace '\s+', '')
    foreach ($n in (Get-CurrentConnectionNames)) {
        if (($n -replace '\s+', '') -eq $want) { return $true }
    }
    return $false
}

# 「连着」不等于「通」。睡一觉起来、路由器重启过、运营商把会话踢掉之后，rasdial
# 照样报「已连接」，可一个包都发不出去。所以掉线重连不能只问 rasdial，得真的连一下。
#
# 【踩过的坑】这里原先用 ICMP ping。实测有两个问题：
#   ① ping 走的是系统 ICMP 通道，不少安全软件 / 防火墙会直接把它拒掉，抛
#      Win32Exception「Access is denied」（本机实测 5 个目标全部如此）；
#   ② 校园网本身也常把 ICMP 掐掉，ping 不通不代表真的没网。
# 两种情况下都会把一条好好的连接判成「假连接」，然后挂断重拨 —— 越修越坏。
# 改成往上连一个 TCP 端口（公共 DNS 的 53）：三次握手能成功就说明真的出得去，
# 普通权限就够，也不会被 ICMP 策略影响。按顺序试，任意一个通就算健康。
function Test-Healthy {
    param([string]$Name)
    if (-not (Test-Connected -Name $Name)) { return $false }
    foreach ($t in $ProbeTargets) {
        $client = $null
        try {
            $client = New-Object Net.Sockets.TcpClient
            $ok = $client.ConnectAsync($t[0], $t[1]).Wait($ProbeTimeoutMs)
            if ($ok -and $client.Connected) { return $true }
        } catch {
            # 这个目标连不上就换下一个，别把异常抛出去
        } finally {
            if ($client) { try { $client.Close() } catch { } }
        }
    }
    return $false
}

# ---------------------------------------------------------------- 拨号
function Invoke-SilentDial {
    param([string]$Name, [string]$UserName, [string]$PlainPassword, [int]$TimeoutSec)

    $argv = @('"' + $Name + '"')
    if (-not [string]::IsNullOrEmpty($UserName)) {
        $argv += '"' + $UserName + '"'
        $argv += '"' + $PlainPassword + '"'
    }

    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName               = $Rasdial
    $psi.Arguments              = ($argv -join ' ')
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.CreateNoWindow         = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::GetEncoding(936)
    $psi.StandardErrorEncoding  = [Text.Encoding]::GetEncoding(936)

    $p = [Diagnostics.Process]::Start($psi)
    if (-not $p.WaitForExit($TimeoutSec * 1000)) {
        # 这里绝对不能直接 Kill。强杀 rasdial 会在 RasMan 里留下一个「正在拨号」
        # 的悬空状态：此后对这个连接的任何拨号都立刻返回错误 756（已经拨了这个
        # 连接），而且用 /disconnect 也清不掉，只能重启电脑。
        # 正确做法是先挂断，让 rasdial 自己收尾退出。
        Write-Log "rasdial 超过 $TimeoutSec 秒未返回，先挂断让它自己结束（不直接强杀）..." 'WARN'
        try { & $Rasdial $Name '/disconnect' 2>&1 | Out-Null } catch {}
        if (-not $p.WaitForExit(10000)) {
            Write-Log '挂断后 rasdial 仍未退出，只能强制结束。若之后一直报 756，重启一次电脑即可清掉。' 'WARN'
            try { $p.Kill() } catch {}
        }
        return [pscustomobject]@{ Ok = $false; TimedOut = $true; ExitCode = $null
                                  Text = "rasdial 超过 $TimeoutSec 秒未返回（已尝试挂断）" }
    }
    $text = ($p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()).Trim()
    return [pscustomobject]@{ Ok = ($p.ExitCode -eq 0); TimedOut = $false; ExitCode = $p.ExitCode; Text = $text }
}

# 把 rasdial 的报错码翻译成用户看得懂、且能照做的一句话。
function Get-RasErrorHint {
    param([string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return $null }
    if ($Text -notmatch '(?:error|错误)\s+(\d{3,4})') { return $null }
    $code = [int]$Matches[1]
    $hint = switch ($code) {
        691     { '账号或密码不对。在「宽带管家」里选中这条宽带，点「改账号密码」重输一次。' }
        623     { '找不到这个拨号连接（连接名不对）。可能这条宽带已经在系统里被删掉了。' }
        651     { 'PPPoE 服务器没响应：检查网线、光猫电源，或者换一个网口。' }
        678     { '拨号无人应答：线路不通。检查网线和光猫。' }
        756     { '系统里已经有一个拨号在进行中（上一次拨号没有正常收尾）。重启一次电脑即可清掉。' }
        769     { '目标地址不可达：网卡还没就绪，稍等再试。' }
        814     { '找不到宽带连接设备（WAN Miniport PPPOE 异常），需要重启电脑。' }
        default { $null }
    }
    if ($hint) { return "错误 $code：$hint" }
    return "rasdial 返回错误 $code。"
}

function Open-DialWindow {
    param([string]$Preferred)
    try {
        if (-not [string]::IsNullOrWhiteSpace($Preferred)) {
            Write-Log "打开系统拨号窗口（$Preferred）..." 'WARN'
            Start-Process -FilePath $Rasphone -ArgumentList @('-d', $Preferred) | Out-Null
        } else {
            Write-Log '打开系统拨号窗口...' 'WARN'
            Start-Process -FilePath $Rasphone | Out-Null
        }
    } catch {
        Write-Log "打开拨号窗口失败：$($_.Exception.Message)" 'ERROR'
    }
}

# 打开「宽带管家」界面。用在「还没配好」的时候：这时候用户需要的是去补账号密码，
# 而不是对着一张系统拨号窗口猜自己该往框里输什么。
function Open-Butler {
    try {
        $gui = Join-Path $PSScriptRoot '一键宽带设置.ps1'
        if (-not (Test-Path -LiteralPath $gui)) { $gui = Join-Path $PSScriptRoot 'SchoolBroadbandSettings.ps1' }
        if (-not (Test-Path -LiteralPath $gui)) {
            Write-Log '同目录下找不到「宽带管家」界面脚本，打不开。' 'WARN'
            return $false
        }
        $exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        # 界面现在自己不会去连接（只显示状态），所以不必再防它跟我们打架。
        Start-Process -FilePath $exe -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $gui + '"')
        ) | Out-Null
        Write-Log '已打开「宽带管家」，请在里面补上宽带账号密码。' 'WARN'
        return $true
    } catch {
        Write-Log "打开「宽带管家」失败：$($_.Exception.Message)" 'ERROR'
        return $false
    }
}

# ---------------------------------------------------------------- 依次尝试
# 核心：把候选宽带一条条试过去，任意一条连上就成功返回。
function Invoke-ConnectAll {
    param($List, [int]$RetryPer, [int]$IntervalSec, [int]$TimeoutSec)

    if ($List.Count -eq 0) { return [pscustomobject]@{ Ok = $false; Reason = '没有配置任何宽带' } }

    # 已经连着清单里的某一条？那就不用拨了。
    foreach ($p in $List) {
        if (Test-Connected -Name $p.name) {
            Write-Log "「$($p.label)」已经是连接状态，无需重复拨号。" 'OK'
            return [pscustomobject]@{ Ok = $true; Reason = '已连接' }
        }
    }

    $tried = 0
    $missingCred = 0
    $lastHint = $null

    foreach ($p in $List) {
        $cred = Get-ProfileCredential -Profile $p
        if (-not $cred) {
            # 这里不跳过。rasdial 不带账号密码时，用的是「电话簿里保存的那份凭据」——
            # 很多机器上 Windows 自己早就把密码存好了（拨号窗口里勾过「保存密码」），
            # 我们自己存的那份只是双保险。所以先拿系统那份试一次，连不上再算。
            $missingCred++
            Write-Log "「$($p.label)」这里还没保存账号密码，先试试系统电话簿里存的那份。" 'WARN'
        }
        $tried++
        for ($i = 1; $i -le $RetryPer; $i++) {
            if ($i -gt 1) {
                Write-Log ("「{0}」第 {1}/{2} 次尝试：等 {3} 秒..." -f $p.label, $i, $RetryPer, $IntervalSec)
                Start-Sleep -Seconds $IntervalSec
            }
            $userName = $(if ($cred) { $cred.User } else { '' })
            $userPass = $(if ($cred) { $cred.Pass } else { '' })
            if ($userName) {
                Write-Log "正在连接「$($p.label)」（$($p.name)，账号 $userName）..."
            } else {
                Write-Log "正在连接「$($p.label)」（$($p.name)，用系统里保存的账号密码）..."
            }
            $r = Invoke-SilentDial -Name $p.name -UserName $userName -PlainPassword $userPass -TimeoutSec $TimeoutSec
            if ($r.Text) { Write-Log $r.Text 'DETAIL' }
            $lastHint = Get-RasErrorHint -Text $r.Text
            if ($lastHint) { Write-Log $lastHint 'WARN' }
            if ($r.Ok -or (Test-Connected -Name $p.name)) {
                Write-Log "「$($p.label)」连接成功。" 'OK'
                return [pscustomobject]@{ Ok = $true; Reason = '连接成功' }
            }
            # 756 = 系统里已经有一个拨号在进行中。这种状态下再重试几次都是同样的
            # 结果，只会白等，所以直接换下一条，不要在这里死磕。
            if ($r.Text -match '(?:error|错误)\s+756') {
                Write-Log '检测到 756，这条先跳过。' 'WARN'
                break
            }
            Write-Log "「$($p.label)」没连上。" 'WARN'
        }
    }

    if ($tried -eq 0) {
        return [pscustomobject]@{ Ok = $false; Reason = '没有可尝试的宽带'; Hint = $lastHint }
    }
    if ($missingCred -ge $tried) {
        # 每一条都是在「我们手里没有账号密码」的情况下试的。这时候失败多半不是网络问题，
        # 而是这台机器上压根没人存过密码 —— 该请用户去补，不该丢个系统拨号窗口给他。
        return [pscustomobject]@{ Ok = $false; Reason = '还没配好'; Hint = $lastHint }
    }
    return [pscustomobject]@{ Ok = $false; Reason = '全部尝试失败'; Hint = $lastHint }
}

# ==================================================================
#  配置管理命令（由设置界面调用；都不拨号，成功 exit 0 / 失败 exit 1）
# ==================================================================
if ($ListConnections) {
    foreach ($n in (Get-PbkNames)) { Write-Host $n }
    exit 0
}

if ($ListProfiles) {
    $list = Read-Profiles
    if ($list.Count -eq 0) { Write-Host '[]'; exit 0 }
    Write-Host (@($list) | ConvertTo-Json -Depth 6 -Compress)
    exit 0
}

if ($SyncStartup) {
    # 安装器装完叫一次：让「启动」文件夹里的快捷方式和 profiles.json 里的勾选保持一致
    Sync-StartupLink -List (Read-Profiles)
    exit 0
}

if ($FastStartStatus) {
    # 只读状态，普通权限就能查，界面每次刷新时叫一次
    $st = 'off'
    try {
        if (Get-ScheduledTask -TaskName $StartupTaskName -ErrorAction SilentlyContinue) { $st = 'on' }
    } catch { $st = 'unknown' }
    Write-Host $st
    exit 0
}

if ($FastStartOn) {
    $vbs = Get-LauncherVbs
    if (-not $vbs) { Write-Log '同目录下找不到启动器 .vbs，没法设置极速启动。' 'ERROR'; exit 1 }
    if (Sync-StartupTask -Enable $true -Vbs $vbs) { exit 0 }
    Write-Log '极速启动没设置成功。具体原因看上面那条 ERROR/WARN。' 'ERROR'
    exit 1
}

if ($FastStartOff) {
    if (Sync-StartupTask -Enable $false -Vbs $null) { exit 0 }
    Write-Log '取消极速启动失败。具体原因看上面那条 ERROR/WARN。' 'ERROR'
    exit 1
}

if ($ReconnectStatus) {
    # 只读状态，普通权限就能查
    $st = 'off'
    try {
        if (Get-ScheduledTask -TaskName $ReconnectTaskName -ErrorAction SilentlyContinue) { $st = 'on' }
    } catch { $st = 'unknown' }
    Write-Host $st
    exit 0
}

if ($ReconnectOn) {
    $vbs = Get-LauncherVbs
    if (-not $vbs) { Write-Log '同目录下找不到启动器 .vbs，没法设置掉线重连。' 'ERROR'; exit 1 }
    if (Sync-ReconnectTask -Enable $true -Vbs $vbs) { exit 0 }
    Write-Log '掉线重连没设置成功。具体原因看上面那条 ERROR —— 通常是系统不让建计划任务。' 'ERROR'
    exit 1
}

if ($ReconnectOff) {
    if (Sync-ReconnectTask -Enable $false -Vbs $null) { exit 0 }
    Write-Log '关闭掉线重连失败，具体原因看上面那条 ERROR。' 'ERROR'
    exit 1
}

$mutated = $false
if ($AddProfile -or $RemoveProfile -or $SetProfile -or $AutoOn -or $AutoOff -or $MoveUp -or $MoveDown) {
    $list = Read-Profiles

    if ($AddProfile) {
        $existing = Find-Profile -List $list -Name $AddProfile
        $enc = ''
        if (-not [string]::IsNullOrEmpty($Password)) { $enc = Protect-Password -Plain $Password }
        elseif ($existing) { $enc = $existing.passwordEnc }
        $label = $AddProfile
        if (-not [string]::IsNullOrWhiteSpace($ProfileLabel)) { $label = $ProfileLabel.Trim() }
        elseif ($existing -and -not [string]::IsNullOrWhiteSpace($existing.label)) { $label = $existing.label }
        if ($existing) {
            $existing.account = [string]$Account
            if ($enc) { $existing.passwordEnc = $enc }
            if ($PSBoundParameters.ContainsKey('AutoStart')) { $existing.autoStart = [bool]$AutoStart }
            Write-Log "已更新宽带「$($existing.label)」。" 'OK'
        } else {
            $newP = [pscustomobject]@{
                name        = $AddProfile
                label       = $label
                account     = [string]$Account
                passwordEnc = $enc
                autoStart   = [bool]$AutoStart
            }
            [void]$list.Add($newP)
            Write-Log "已添加宽带「$($newP.label)」。" 'OK'
        }
        $mutated = $true
    }

    if ($RemoveProfile) {
        $p = Find-Profile -List $list -Name $RemoveProfile
        if (-not $p) { Write-Log "没有这条宽带：$RemoveProfile" 'ERROR'; exit 1 }
        [void]$list.Remove($p)
        Write-Log "已删除宽带「$($p.label)」。" 'OK'
        $mutated = $true
    }

    if ($SetProfile) {
        $p = Find-Profile -List $list -Name $SetProfile
        if (-not $p) { Write-Log "没有这条宽带：$SetProfile" 'ERROR'; exit 1 }
        if ($PSBoundParameters.ContainsKey('Account')) { $p.account = [string]$Account }
        if (-not [string]::IsNullOrEmpty($Password)) { $p.passwordEnc = Protect-Password -Plain $Password }
        Write-Log "已更新宽带「$($p.label)」的账号密码。" 'OK'
        $mutated = $true
    }

    if ($AutoOn) {
        $p = Find-Profile -List $list -Name $AutoOn
        if (-not $p) { Write-Log "没有这条宽带：$AutoOn" 'ERROR'; exit 1 }
        $p.autoStart = $true
        Write-Log "「$($p.label)」的开机自启已打开。" 'OK'
        $mutated = $true
    }

    if ($AutoOff) {
        $p = Find-Profile -List $list -Name $AutoOff
        if (-not $p) { Write-Log "没有这条宽带：$AutoOff" 'ERROR'; exit 1 }
        $p.autoStart = $false
        Write-Log "「$($p.label)」的开机自启已关闭。" 'OK'
        $mutated = $true
    }

    if ($MoveUp -or $MoveDown) {
        $target = $(if ($MoveUp) { $MoveUp } else { $MoveDown })
        $idx = -1
        for ($i = 0; $i -lt $list.Count; $i++) { if ($list[$i].name -eq $target) { $idx = $i; break } }
        if ($idx -lt 0) { Write-Log "没有这条宽带：$target" 'ERROR'; exit 1 }
        $newIdx = $(if ($MoveUp) { $idx - 1 } else { $idx + 1 })
        if ($newIdx -lt 0 -or $newIdx -ge $list.Count) {
            Write-Log '已经在最前面/最后面了。' 'INFO'
        } else {
            $item = $list[$idx]
            $list.RemoveAt($idx)
            $list.Insert($newIdx, $item)
            Write-Log "已调整「$($item.label)」的尝试顺序。" 'OK'
        }
        $mutated = $true
    }

    if ($mutated) {
        Write-Profiles -List $list
        Sync-StartupLink -List $list
    }
    exit 0
}

# ==================================================================
#  状态查询
# ==================================================================
$all = Read-Profiles

if ($Status) {
    if ($all.Count -eq 0) { Write-Host '还没有配置任何宽带。'; exit 1 }
    $anyOn = $false
    foreach ($p in $all) {
        $on = Test-Connected -Name $p.name
        if ($on) { $anyOn = $true }
        Write-Host ("  {0} {1}（{2}）{3}" -f $(if ($on) { '[已连接]' } else { '[未连接]' }),
                    $p.label, $p.name, $(if ($p.autoStart) { ' 开机自启' } else { '' }))
    }
    if ($anyOn) { exit 0 } else { exit 1 }
}

# ==================================================================
#  连接
# ==================================================================
if (-not ($Connect -or $AutoConnect -or $Reconnect)) {
    Write-Host '用法：-Connect 立即连接 / -AutoConnect 开机自连 / -Status 查状态 / 详见脚本头部注释。'
    exit 2
}

if ($all.Count -eq 0) {
    Write-Log '还没有配置任何宽带。请先打开「宽带管家」添加一条。' 'ERROR'
    # 一条都没配的时候，弹系统拨号窗口没有意义：用户对着它也不知道该输什么。
    # 直接把人带到「宽带管家」，那里能把连接和账号密码一次填完。
    if ($FallbackToUi) { [void](Open-Butler) }
    exit 2
}

# -Reconnect：计划任务定期调用的「体检」入口。它和开机自连只差一点 ——
# 「已经连着」不算过关，还得真的能通。睡眠唤醒、路由器重启、运营商把会话踢了之后，
# 经常出现「rasdial 说已连接、其实一个包都发不出去」的假连接，只问 rasdial 会漏掉。
if ($Reconnect) {
    $AutoConnect = $true     # 之后按开机自连的路子走：只试开了自启的那些
    $healthy = $false
    foreach ($p in @($all | Where-Object { $_.autoStart })) {
        if (Test-Healthy -Name $p.name) {
            Write-Log "体检：「$($p.label)」在线且通畅，什么都不用做。" 'OK'
            $healthy = $true
            break
        }
        if (Test-Connected -Name $p.name) {
            Write-Log "体检：「$($p.label)」显示已连接但连不出去（假连接），先挂断再重拨。" 'WARN'
            try { & $Rasdial $p.name '/disconnect' 2>&1 | Out-Null } catch { }
            Start-Sleep -Seconds 2
        }
    }
    if ($healthy) { exit 0 }
    Write-Log '体检：当前没有可用连接，开始重拨。' 'WARN'
}

if ($AutoConnect) {
    $targets = @($all | Where-Object { $_.autoStart })
    Write-Log ("=== 开机自动连接：{0} 条宽带开了自启，将依次尝试 ===" -f $targets.Count)
    # 记一笔「系统开机到现在过了多久」。拿它减去 Windows 自身的启动和登录耗时，
    # 剩下的就是「登录之后排队等我们跑」的时间 —— 也就是「启动」文件夹那一段延迟。
    # Environment.TickCount 是系统已运行的毫秒数，不需要任何权限就能读。
    try {
        $up = [TimeSpan]::FromMilliseconds([Environment]::TickCount)
        Write-Log ("系统已开机 {0} 分 {1} 秒（减去 Windows 自己启动登录的时间，剩下的就是排队等我们的时间）。" -f [int]$up.TotalMinutes, $up.Seconds)
    } catch { }
    if ($targets.Count -eq 0) {
        Write-Log '没有任何宽带开启开机自启，什么都不做。' 'INFO'
        exit 0
    }
} else {
    # 手动连接：全部都试，开了自启的排前面（用户最可能想连的那条）
    $auto  = @($all | Where-Object { $_.autoStart })
    $rest  = @($all | Where-Object { -not $_.autoStart })
    $targets = @($auto) + @($rest)
    Write-Log ("=== 立即连接：{0} 条宽带，按顺序尝试 ===" -f $targets.Count)
}

# 开机自连：登录后网卡/PPPoE 端口可能还没就绪。以前是一上来就傻等固定秒数，
# 白白拖慢开机；现在改成轮询网卡状态，一就绪立刻开始拨号。
if ($AutoConnect -and $WarmupSec -gt 0 -and -not $Reconnect) {
    # -Reconnect 不等网卡：系统早就醒着，网卡也是现成的，等那 15 秒纯粹是浪费
    $waited = Wait-NetworkReady -MaxSec $WarmupSec
    if ($waited -ge 0) {
        Write-Log "网卡已就绪（等了 $waited 秒），开始拨号。"
    } else {
        Write-Log "等了 $WarmupSec 秒还没看到可用的网卡，先试一次看看。" 'WARN'
    }
    foreach ($p in $targets) {
        if (Test-Connected -Name $p.name) {
            Write-Log "等待期间发现「$($p.label)」已经连上了，无需拨号。" 'OK'
            exit 0
        }
    }
}

$result = Invoke-ConnectAll -List $targets -RetryPer $RetryPerProfile -IntervalSec $RetryIntervalSec -TimeoutSec $SilentTimeoutSec

if ($result.Ok) { exit 0 }

if ($result.Reason -eq '还没配好') {
    Write-Log '连接失败。这些宽带都还没保存账号密码，得先补上。' 'ERROR'
} elseif ($result.Hint) {
    Write-Log "连接失败。$($result.Hint)" 'ERROR'
} else {
    Write-Log '连接失败。请检查：账号密码是否正确 / 网线是否插好 / 是否欠费停机。' 'ERROR'
}

if ($FallbackToUi) {
    if ($result.Reason -eq '还没配好' -or $result.Reason -eq '没有可尝试的宽带') {
        # 「还没配好」不是「连不上」，是「还没告诉它怎么连」。
        # 这种情况弹系统拨号窗口只会让人更糊涂（那个窗口的密码框还是空的），
        # 直接打开「宽带管家」，用户能在那儿把账号密码一次填完。
        [void](Open-Butler)
    } else {
        $preferred = $(if ($targets.Count -gt 0) { $targets[0].name } else { $null })
        Open-DialWindow -Preferred $preferred
    }
}

exit 1
