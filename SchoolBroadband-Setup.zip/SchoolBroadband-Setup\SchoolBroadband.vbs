' SchoolBroadband.vbs ���� silent launcher (no console window)
' With -AutoConnect it runs the logon auto-connect mode. With -Reconnect it runs the
' periodic health check (scheduled task). Both stay completely silent: no balloon on
' success (the user can already browse), and no modal dialog on failure.
Option Explicit

Dim fso, sh, here, exe, ps1Main, ps1Gui, i, auto, reconn, rc
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")

Function FindScript(folder, names)
    Dim k, p
    For k = 0 To UBound(names)
        p = fso.BuildPath(folder, names(k))
        If fso.FileExists(p) Then
            FindScript = p
            Exit Function
        End If
    Next
    FindScript = ""
End Function

here = fso.GetParentFolderName(WScript.ScriptFullName)
exe  = sh.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"

ps1Main = FindScript(here, Array("SchoolBroadband.ps1"))
ps1Gui  = FindScript(here, Array("SchoolBroadbandSettings.ps1"))

If ps1Main = "" Then
    MsgBox "Main script missing:" & vbCrLf & "SchoolBroadband.ps1", 16, "Broadband Butler"
    WScript.Quit 2
End If

auto   = False
reconn = False
For i = 0 To WScript.Arguments.Count - 1
    If LCase(WScript.Arguments(i)) = "-autoconnect" Then auto = True
    If LCase(WScript.Arguments(i)) = "-reconnect"   Then reconn = True
Next

If reconn Then
    ' Health check: if a connection exists but no longer passes traffic, hang it up and
    ' redial. Deliberately NO -FallbackToUi: this runs every 15 minutes in the background
    ' and must never open a window behind the user's back.
    rc = sh.Run("""" & exe & """ -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1Main & """ -Reconnect", 0, True)
    WScript.Quit rc
ElseIf auto Then
    ' Logon auto-connect: try every profile that has auto-start switched on, one after
    ' another. If none of them connects, the main script opens the Windows dial-up
    ' window itself (-FallbackToUi), so nothing else pops up here.
    rc = sh.Run("""" & exe & """ -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1Main & """ -AutoConnect -FallbackToUi", 0, True)
    ' Deliberately silent on success as well: the moment the connection is up the
    ' user can already browse, so a balloon tip only gets in the way.
    WScript.Quit rc
Else
    ' Double-click: just open the manager window. It deliberately does NOT dial on its
    ' own -- a double-click is for getting the window up fast, and connecting is one
    ' button away (the leftmost button in the window).
    If ps1Gui = "" Then
        MsgBox "Manager script missing:" & vbCrLf & "SchoolBroadbandSettings.ps1", 16, "Broadband Butler"
        WScript.Quit 2
    End If
    sh.Run """" & exe & """ -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1Gui & """", 0, False
    WScript.Quit 0
End If