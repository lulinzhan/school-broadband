﻿<#
  install.ps1 —— 一键宽带安装器
  复制文件 -> 建桌面图标 -> 建开始菜单 -> 列出候选连接
  只写当前用户目录，不需要管理员权限。
#>
[CmdletBinding()]
param(
    [switch]$Silent,          # 不弹确认框（安装包 exe 默认传这个）
    [switch]$NoShortcuts,     # 不建快捷方式（调试用）
    [switch]$NoLaunch         # 装完不自动打开管理界面
)

$ErrorActionPreference = 'Stop'

$Source    = Split-Path -Parent $MyInvocation.MyCommand.Path
# 把工作目录固定到脚本自己所在的目录。双击 install.bat 时它可能是别处，
# 甚至可能是没有写权限的目录（管理员终端默认就是 System32），
# 那样后面任何相对路径都会莫名其妙地「访问被拒绝」。
Set-Location -LiteralPath $Source
# %LOCALAPPDATA% 为空时 Join-Path 会抛出一个看不懂的异常，这里自己兜一层
$LocalRoot = $env:LOCALAPPDATA
if ([string]::IsNullOrWhiteSpace($LocalRoot)) { $LocalRoot = [Environment]::GetFolderPath('LocalApplicationData') }
if ([string]::IsNullOrWhiteSpace($LocalRoot)) { $LocalRoot = Join-Path $env:USERPROFILE 'AppData\Local' }
$InstallTo = Join-Path $LocalRoot 'Programs\SchoolBroadband'

Write-Host ''
Write-Host '  ==============================================='
Write-Host '   宽带管家 安装程序'
Write-Host '  ==============================================='
Write-Host ''
Write-Host ("  安装位置：{0}" -f $InstallTo)
Write-Host ''

if (-not $Silent) {
    $ans = Read-Host '  按回车开始安装（输入 n 取消）'
    if ($ans -match '^[nN]') { Write-Host '  已取消。'; exit 1 }
}

if (-not (Test-Path -LiteralPath $InstallTo)) {
    try {
        New-Item -ItemType Directory -Path $InstallTo -Force | Out-Null
    } catch {
        Write-Host ''
        Write-Host ("  安装目录建不出来：{0}" -f $InstallTo) -ForegroundColor Red
        Write-Host ("  原因：{0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Host '  多半是安全软件拦住了写入。可以改用压缩包方式安装'
        Write-Host '  （解压 SchoolBroadband-Setup.zip，双击里面的 install.bat），'
        Write-Host '  或者把本程序加入安全软件白名单后重试。'
        Write-Host ''
        if (-not $Silent) { Read-Host '  按回车退出' | Out-Null }
        exit 1
    }
}

$files = @('SchoolBroadband.ps1', 'SchoolBroadband.vbs', 'SchoolBroadbandSettings.ps1', 'uninstall.ps1', 'README.txt')
foreach ($f in $files) {
    $src = Join-Path $Source $f
    if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $InstallTo $f) -Force
        Write-Host ("  已安装 {0}" -f $f)
    } else {
        Write-Host ("  警告：缺少 {0}" -f $f) -ForegroundColor Yellow
    }
}

if (-not $NoShortcuts) {
    $vbs = Join-Path $InstallTo 'SchoolBroadband.vbs'
    $ws  = New-Object -ComObject WScript.Shell

    function New-Lnk([string]$Path, [string]$Desc, [string]$Launcher) {
        $lnk = $ws.CreateShortcut($Path)
        $lnk.TargetPath       = (Join-Path $env:SystemRoot 'System32\wscript.exe')
        $lnk.Arguments        = '"{0}"' -f $Launcher
        $lnk.WorkingDirectory = $InstallTo
        $lnk.IconLocation     = '{0},14' -f (Join-Path $env:SystemRoot 'System32\SHELL32.dll')
        $lnk.Description      = $Desc
        $lnk.Save()
    }

    # 桌面只留一个图标：它同时是「连接」和「管理」的入口，免得堆两个图标分不清。
    $desktop = [Environment]::GetFolderPath('Desktop')
    New-Lnk (Join-Path $desktop '宽带管家.lnk') '开机自动连接宽带 / 管理多条宽带' $vbs
    Write-Host '  已创建桌面图标：宽带管家'

    $startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) '宽带管家'
    if (-not (Test-Path -LiteralPath $startMenu)) { New-Item -ItemType Directory -Path $startMenu -Force | Out-Null }
    New-Lnk (Join-Path $startMenu '宽带管家.lnk') '开机自动连接宽带 / 管理多条宽带' $vbs
    Write-Host '  已创建开始菜单项：宽带管家'

    # 覆盖安装：清掉老版本留下的图标（老版本在桌面放了「学校宽带」「宽带设置」两个）
    $programs = [Environment]::GetFolderPath('Programs')
    foreach ($old in @(
        (Join-Path $desktop  '学校宽带.lnk'),
        (Join-Path $desktop  '宽带设置.lnk'),
        (Join-Path $programs '一键宽带'))) {
        if (Test-Path -LiteralPath $old) {
            Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host ("  已清理旧版本残留：{0}" -f $old)
        }
    }
}

# 老版本在安装目录里放过一个专门的设置启动器，现在不需要了；
# 老版本在「启动」文件夹里用的快捷方式名也和现在不一样。都清掉，
# 再让主脚本按 profiles.json 里的勾选，重建正确名字的那个启动项。
$staleItems = @(
    (Join-Path $InstallTo 'SchoolBroadbandSettings.vbs'),
    (Join-Path ([Environment]::GetFolderPath('Startup')) '一键宽带-自动连接.lnk')
)
foreach ($stale in $staleItems) {
    if (Test-Path -LiteralPath $stale) {
        Remove-Item -LiteralPath $stale -Force -ErrorAction SilentlyContinue
        Write-Host ("  已清理旧版本残留：{0}" -f $stale)
    }
}

$mainScript = Join-Path $InstallTo 'SchoolBroadband.ps1'
if (Test-Path -LiteralPath $mainScript) {
    try { Set-Location -LiteralPath $InstallTo } catch {}
    & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') `
        -NoProfile -ExecutionPolicy Bypass -File $mainScript -SyncStartup | Out-Null
}

Write-Host ''
Write-Host '  正在检查拨号连接...'
# 直接在本进程内读电话簿，不启 powershell 子进程
$pbks = @(
    (Join-Path $env:APPDATA 'Microsoft\Network\Connections\Pbk\rasphone.pbk'),
    (Join-Path $env:ProgramData 'Microsoft\Network\Connections\Pbk\rasphone.pbk')
)
$conns = @()
foreach ($f in $pbks) {
    if (Test-Path -LiteralPath $f) {
        $text = $null
        try {
            # rasphone.pbk 在 Win10/11 上是 UTF-8（通常无 BOM）。
            # 按系统 ANSI 硬读会把「宽带连接 3」读成「瀹藉甫杩炴帴 3」，这个乱码名字拿去做 rasdial 必然失败。
            $text = [IO.File]::ReadAllText($f, (New-Object Text.UTF8Encoding($false, $true)))
        } catch {
            $text = [IO.File]::ReadAllText($f, [Text.Encoding]::GetEncoding(936))
        }
        foreach ($line in ($text -split "`r?`n")) {
            $t = $line.Trim()
            if ($t.Length -gt 2 -and $t.StartsWith('[') -and $t.EndsWith(']')) {
                $conns += $t.Substring(1, $t.Length - 2)
            }
        }
    }
}
if ($conns.Count -eq 0) {
    Write-Host '  没找到拨号连接。请先在 Windows 设置里建好宽带连接。' -ForegroundColor Yellow
} else {
    Write-Host ("  找到 {0} 个连接：{1}" -f $conns.Count, ($conns -join '、'))
    Write-Host ("  将使用：{0}" -f $conns[0]) -ForegroundColor Green
}
Write-Host ''

# 装完顺手把管理界面打开：用户第一次进来就能添加宽带、勾上「开机自动连接」。
if (-not $NoLaunch -and -not $NoShortcuts) {
    $gui = Join-Path $InstallTo 'SchoolBroadbandSettings.ps1'
    if (Test-Path -LiteralPath $gui) {
        try {
            Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') `
                -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
                                '-File', ('"' + $gui + '"'))
        } catch {}
    }
}

Write-Host '  安装完成。' -ForegroundColor Green
Write-Host '  桌面上的「宽带管家」就是全部入口：双击打开它，既能连、也能管。'
Write-Host '  第一次用：点「添加宽带」选一条系统里已有的宽带，填一次账号密码，'
Write-Host '  再给需要开机自动连的那条打上勾即可。想现在就上网，点「立即连接」。'
Write-Host ''
if (-not $Silent) { Read-Host '  按回车退出' | Out-Null }
exit 0