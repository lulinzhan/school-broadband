﻿<#
  宽带管家 —— 管理界面
  ==================================================================
  双击桌面「宽带管家」图标打开这个窗口。能做的事：
    · 添加 / 删除宽带（连接名从系统电话簿里选）
    · 给每条宽带单独开关「开机自动连接」（勾选框）
    · 调整尝试顺序（开机后按这个顺序一条条试）
    · 改某条宽带的账号密码
    · 立即连接（手动点这个按钮才开始连）
    · 查看日志

  设计取舍：它自己不拨号、也不碰 profiles.json，所有动作都转交给同目录的主脚本
  执行。这样「哪些宽带开机自启」只有一套实现，不会出现界面和主脚本两边判断不一致。

  打开窗口本身【不】去连接，只显示当前状态 —— 双击是为了马上看到窗口，想连的时候
  点「立即连接」。开机自连和掉线重连都不受影响：那两条走的是 VBS + 计划任务，
  根本不经过这个界面。
#>

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Add-Type -AssemblyName System.Windows.Forms | Out-Null
Add-Type -AssemblyName System.Drawing | Out-Null

# 见主脚本里的同名函数：%LOCALAPPDATA% 为空时不能直接拿去 Join-Path
function Get-DataRoot {
    $cands = @(
        $env:LOCALAPPDATA,
        [Environment]::GetFolderPath('LocalApplicationData'),
        $(if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) { Join-Path $env:USERPROFILE 'AppData\Local' }),
        $env:TEMP
    )
    foreach ($c in $cands) {
        if (-not [string]::IsNullOrWhiteSpace($c)) { return $c }
    }
    return (Get-Location).Path
}
$StoreDir = Join-Path (Get-DataRoot) 'SchoolBroadband'
$LogFile  = Join-Path $StoreDir 'last-run.log'
$ProfilesFile = Join-Path $StoreDir 'profiles.json'
$script:SuppressCheck = $false

# 这两个名字必须和主脚本里的 $StartupTaskName / $ReconnectTaskName 保持一致 ——
# 界面上那两个勾选框显示的开 / 关，就是「系统里有没有这个计划任务」。
$TaskNameFastStart = '宽带管家-开机自动连接'
$TaskNameReconnect = '宽带管家-掉线自动重连'

function Get-MainScript {
    foreach ($c in @('SchoolBroadband.ps1', '一键宽带.ps1', '宽带管家.ps1')) {
        $p = Join-Path $PSScriptRoot $c
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

$MainScript = Get-MainScript
if (-not $MainScript) {
    [Windows.Forms.MessageBox]::Show(
        "同目录下找不到主脚本（SchoolBroadband.ps1 或 一键宽带.ps1）。",
        '宽带管家', 'OK', 'Error') | Out-Null
    exit 2
}

# 拼接命令行参数：值里带空格的必须整体加引号，否则 PowerShell 会把它拆成两个参数。
# 比如「宽带连接 3」会被拆成「宽带连接」和「3」，主脚本就回一句
# 「没有这条宽带：宽带连接」——勾开机自启、改密码、删除、上移下移都会这样哑掉。
function ConvertTo-ArgList {
    param([string[]]$Items)
    $out = @()
    foreach ($it in $Items) {
        if ($it -like '-*' -and $it -notmatch '\s') { $out += $it }
        else { $out += ('"' + ($it -replace '"', '\"') + '"') }
    }
    return ($out -join ' ')
}

# 转交给主脚本执行；返回退出码 + 输出文本
function Invoke-Main {
    param([string[]]$MainArgs = @(), [switch]$Capture)
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName        = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $MainScript)
    if ($MainArgs.Count -gt 0) { $a += $MainArgs }
    $psi.Arguments       = (ConvertTo-ArgList -Items $a)
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true
    if ($Capture) {
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
        $psi.StandardErrorEncoding  = [Text.Encoding]::UTF8
    }
    try {
        $p = [Diagnostics.Process]::Start($psi)
        if ($Capture) {
            $out = $p.StandardOutput.ReadToEnd()
            $err = $p.StandardError.ReadToEnd()
            $p.WaitForExit()
            return [pscustomobject]@{ Code = $p.ExitCode; Out = $out; Err = $err }
        }
        $p.WaitForExit()
        return [pscustomobject]@{ Code = $p.ExitCode; Out = ''; Err = '' }
    } catch {
        return [pscustomobject]@{ Code = -1; Out = ''; Err = $_.Exception.Message }
    }
}

# 现在连着没有 —— 直接问系统网络接口：不起子进程、不解析任何文字，最快也最稳。
#
# 【踩过的坑】这里以前是跑一次 rasdial，再拿正则去匹配「已连接 宽带连接」这种
# 挤在同一行的排版。可 rasdial 实际是分两行印的：
#       已连接
#       宽带连接
#       命令已完成。
# 所以一条都匹配不上 —— 状态栏永远显示「未连接」，哪怕网好好的。
# 现在改成问 NetworkInterface：拨通的 PPPoE 连接会以 Type = Ppp、Status = Up
# 出现，名字就是连接名。结构化数据，不受系统语言、控制台编码、rasdial 排版影响，
# 而且不用起子进程，比原来还快。
function Get-ConnectedNames {
    $names = @()
    try {
        foreach ($ni in [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
            if ($ni.NetworkInterfaceType -eq 'Ppp' -and $ni.OperationalStatus.ToString() -eq 'Up') {
                $names += $ni.Name
            }
        }
    } catch {}
    return @($names)
}

function Test-ConnectedNow { return ((Get-ConnectedNames).Count -gt 0) }

# 后台跑主脚本、不等待：连接要十几秒，界面不能卡在那儿
function Start-MainAsync {
    param([string[]]$MainArgs = @())
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName        = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $MainScript)
    if ($MainArgs.Count -gt 0) { $a += $MainArgs }
    $psi.Arguments       = (ConvertTo-ArgList -Items $a)
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true
    try { return [Diagnostics.Process]::Start($psi) } catch { return $null }
}

# 读电话簿里的连接名（编码处理和主脚本一致：pbk 是 UTF-8，按 ANSI 硬读会得到乱码）
function Get-PbkNames {
    $names = @()
    foreach ($f in @(
        (Join-Path $env:APPDATA 'Microsoft\Network\Connections\Pbk\rasphone.pbk'),
        (Join-Path $env:ProgramData 'Microsoft\Network\Connections\Pbk\rasphone.pbk'))) {
        if (-not (Test-Path -LiteralPath $f)) { continue }
        $text = $null
        try   { $text = [IO.File]::ReadAllText($f, (New-Object Text.UTF8Encoding($false, $true))) }
        catch { $text = [IO.File]::ReadAllText($f, [Text.Encoding]::GetEncoding(936)) }
        foreach ($line in ($text -split "`r?`n")) {
            $t = $line.Trim()
            if ($t.Length -gt 2 -and $t.StartsWith('[') -and $t.EndsWith(']')) {
                $names += $t.Substring(1, $t.Length - 2)
            }
        }
    }
    return @($names | Select-Object -Unique)
}

function Get-Profiles {
    # 直接读文件，比启一个 PowerShell 去跑 -ListProfiles 快几百毫秒 —— 而这正好卡在
    # 「双击之后窗口什么时候出来」这条路上。只有文件还不存在时（从没跑过主脚本、
    # 旧版配置还没迁移过来）才退回去问主脚本。
    if (Test-Path -LiteralPath $ProfilesFile) {
        try {
            $obj = [IO.File]::ReadAllText($ProfilesFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
            if ($obj -and $obj.profiles) { return @($obj.profiles) }
            return @()
        } catch { }
    }
    $r = Invoke-Main -MainArgs @('-ListProfiles') -Capture
    if ($r.Code -ne 0 -and [string]::IsNullOrWhiteSpace($r.Out)) { return @() }
    $json = $null
    foreach ($ln in ($r.Out -split "`r?`n")) {
        $t = $ln.Trim()
        if ($t.StartsWith('[') -or $t.StartsWith('{')) { $json = $t }
    }
    if (-not $json) { return @() }
    try { return @($json | ConvertFrom-Json) } catch { return @() }
}

# 计划任务在不在。刻意不用 Get-ScheduledTask：那个 cmdlet 要先加载 ScheduledTasks
# 模块，实测要一两秒，窗口会因此晚出来。schtasks.exe 是原生小程序，几十毫秒就返回，
# 而我们只关心「存在与否」，看退出码就够。
function Test-TaskExists {
    param([string]$TaskName)
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName        = Join-Path $env:SystemRoot 'System32\schtasks.exe'
    $psi.Arguments       = '/query /tn "' + $TaskName + '"'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    try {
        $p = [Diagnostics.Process]::Start($psi)
        $p.StandardOutput.ReadToEnd() | Out-Null
        $p.StandardError.ReadToEnd()  | Out-Null
        $p.WaitForExit()
        return ($p.ExitCode -eq 0)
    } catch { return $false }
}

# 查「极速启动」现在是开还是关：on / off
function Get-FastStartState {
    if (Test-TaskExists $TaskNameFastStart) { return 'on' }
    return 'off'
}

# 查「掉线自动重连」现在是开还是关。和极速启动一样，看的是计划任务在不在。
function Get-ReconnectState {
    if (Test-TaskExists $TaskNameReconnect) { return 'on' }
    return 'off'
}

# 失败时别只丢一句「详情看日志」—— 用户不会真去翻那个文件，问题就烂在那儿了。
# 直接把日志末尾的 ERROR / WARN 摘出来摆在弹窗里，才有机会被解决。
function Get-FailureMessage {
    param([string]$What)
    $lines = @()
    try {
        if (Test-Path -LiteralPath $LogFile) {
            $lines = @(Get-Content -LiteralPath $LogFile -Tail 60 -Encoding UTF8 -ErrorAction SilentlyContinue |
                       Where-Object { $_ -match '\[(ERROR|WARN)\]' } | Select-Object -Last 4)
        }
    } catch { }
    $msg = "$What 失败。"
    if ($lines.Count -gt 0) {
        $msg += "`r`n`r`n原因：`r`n" + (($lines | ForEach-Object { $_.Trim() }) -join "`r`n")
    } else {
        $msg += "`r`n`r`n日志里没有更多线索，完整日志：`r`n$LogFile"
    }
    return $msg
}

# 用管理员身份再跑一次主脚本。现在只有两种情况会用到它：
#   1) 卸载（要删程序文件、注销计划任务）
#   2) 这台机器上以前用管理员身份建过同名的开机计划任务，标准权限改不动它
# 返回 0 表示成功，-1 表示用户在 UAC 弹窗上点了「否」或者提权本身失败。
function Invoke-Elevated {
    param([string[]]$MainArgs = @())
    $exe  = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $line = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $MainScript + '"'
    if ($MainArgs.Count -gt 0) { $line += ' ' + (ConvertTo-ArgList -Items $MainArgs) }
    try {
        $p = Start-Process -FilePath $exe -ArgumentList $line -Verb RunAs -Wait -PassThru -ErrorAction Stop
        return $p.ExitCode
    } catch {
        return -1
    }
}

# ------------------------------------------------------------------ 界面
$form = New-Object Windows.Forms.Form
$form.Text            = '宽带管家'
$form.ClientSize      = New-Object Drawing.Size(624, 436)
$form.StartPosition   = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox     = $false
$form.Font            = New-Object Drawing.Font('Microsoft YaHei UI', 9)

$lblTitle = New-Object Windows.Forms.Label
$lblTitle.Text     = '宽带管家'
$lblTitle.Font     = New-Object Drawing.Font('Microsoft YaHei UI', 15, [Drawing.FontStyle]::Bold)
$lblTitle.Location = New-Object Drawing.Point(16, 10)
$lblTitle.AutoSize = $true

$lblDesc = New-Object Windows.Forms.Label
$lblDesc.Text      = '打开这个窗口不会自动连接。开机后会把下面【勾选】的宽带一条条试过去，连上就停；一条都连不上时会打开系统拨号窗口。'
$lblDesc.Location  = New-Object Drawing.Point(18, 46)
$lblDesc.AutoSize  = $true
$lblDesc.ForeColor = [Drawing.Color]::FromArgb(80, 80, 80)

$lv = New-Object Windows.Forms.ListView
$lv.Location      = New-Object Drawing.Point(18, 72)
$lv.Size          = New-Object Drawing.Size(588, 190)
$lv.View          = 'Details'
$lv.CheckBoxes    = $true
$lv.FullRowSelect = $true
$lv.GridLines     = $false
$lv.HeaderStyle   = 'Nonclickable'
$lv.HideSelection = $false
[void]$lv.Columns.Add('宽带', 180)
[void]$lv.Columns.Add('系统里的连接', 190)
[void]$lv.Columns.Add('账号', 190)

$btnAdd = New-Object Windows.Forms.Button
$btnAdd.Text = '添加宽带'; $btnAdd.Location = New-Object Drawing.Point(18, 272); $btnAdd.Size = New-Object Drawing.Size(96, 30)

$btnDel = New-Object Windows.Forms.Button
$btnDel.Text = '删除'; $btnDel.Location = New-Object Drawing.Point(120, 272); $btnDel.Size = New-Object Drawing.Size(72, 30)

$btnUp = New-Object Windows.Forms.Button
$btnUp.Text = '上移'; $btnUp.Location = New-Object Drawing.Point(198, 272); $btnUp.Size = New-Object Drawing.Size(64, 30)

$btnDown = New-Object Windows.Forms.Button
$btnDown.Text = '下移'; $btnDown.Location = New-Object Drawing.Point(268, 272); $btnDown.Size = New-Object Drawing.Size(64, 30)

$btnCred = New-Object Windows.Forms.Button
$btnCred.Text = '改账号密码'; $btnCred.Location = New-Object Drawing.Point(338, 272); $btnCred.Size = New-Object Drawing.Size(104, 30)

$btnConnect = New-Object Windows.Forms.Button
$btnConnect.Text = '立即连接'; $btnConnect.Location = New-Object Drawing.Point(18, 312); $btnConnect.Size = New-Object Drawing.Size(104, 32)

$btnLog = New-Object Windows.Forms.Button
$btnLog.Text = '查看日志'; $btnLog.Location = New-Object Drawing.Point(416, 312); $btnLog.Size = New-Object Drawing.Size(92, 32)

$btnClose = New-Object Windows.Forms.Button
$btnClose.Text = '关闭'; $btnClose.Location = New-Object Drawing.Point(514, 312); $btnClose.Size = New-Object Drawing.Size(92, 32)

$btnUninstall = New-Object Windows.Forms.Button
$btnUninstall.Text = '卸载'; $btnUninstall.Location = New-Object Drawing.Point(130, 312); $btnUninstall.Size = New-Object Drawing.Size(78, 32)

$lblStatus = New-Object Windows.Forms.Label
$lblStatus.Location  = New-Object Drawing.Point(18, 354)
$lblStatus.Size      = New-Object Drawing.Size(588, 20)
$lblStatus.ForeColor = [Drawing.Color]::FromArgb(90, 90, 90)

$cbFast = New-Object Windows.Forms.CheckBox
$cbFast.Text     = '开机极速启动（登录后立刻拨号，跳过「启动」文件夹的十几秒延迟）'
$cbFast.Location = New-Object Drawing.Point(18, 382)
$cbFast.Size     = New-Object Drawing.Size(588, 22)

# 「掉线自动重连」和「开机自连」的分工：开机自连只管开机那一下；这个管之后的所有意外 ——
# 睡眠唤醒、路由器重启、运营商把会话踢掉。它挂的是「拨号断开 / 网络断开 / 从睡眠唤醒」
# 这几类系统事件，所以掉线几秒就会被叫醒；另外还有每 15 分钟的兜底体检。
# 而且它不只问「连没连上」，还会真的往上连一个 TCP 端口试试通不通，专门抓那种
# 「显示已连接其实是死的」。
$cbReconn = New-Object Windows.Forms.CheckBox
$cbReconn.Text     = '掉线自动重连（掉线或睡眠唤醒后几秒自动接回来；不需要管理员）'
$cbReconn.Location = New-Object Drawing.Point(18, 406)
$cbReconn.Size     = New-Object Drawing.Size(588, 22)

# ------------------------------------------------------------------ 刷新
function Update-List {
    $script:SuppressCheck = $true
    $lv.BeginUpdate()
    $lv.Items.Clear()
    foreach ($p in (Get-Profiles)) {
        $it = New-Object Windows.Forms.ListViewItem([string]$p.label)
        [void]$it.SubItems.Add([string]$p.name)
        [void]$it.SubItems.Add($(if ([string]::IsNullOrWhiteSpace($p.account)) { '（未设置）' } else { [string]$p.account }))
        $it.Checked = [bool]$p.autoStart
        $it.Tag = [string]$p.name
        [void]$lv.Items.Add($it)
    }
    $lv.EndUpdate()
    $script:SuppressCheck = $false
    $btnCred.Enabled = ($lv.Items.Count -gt 0)
    $btnDel.Enabled  = ($lv.Items.Count -gt 0)
    $btnUp.Enabled   = ($lv.Items.Count -gt 1)
    $btnDown.Enabled = ($lv.Items.Count -gt 1)
}

function Get-SelectedName {
    if ($lv.SelectedItems.Count -eq 0) { return $null }
    return [string]$lv.SelectedItems[0].Tag
}

# ------------------------------------------------------------------ 小对话框
function Show-AddDialog {
    $names = @(Get-PbkNames)
    if ($names.Count -eq 0) {
        [Windows.Forms.MessageBox]::Show(
            "系统电话簿里没有任何宽带连接。`r`n`r`n请先在 Windows 里建一个宽带连接（设置 -> 网络和 Internet -> 拨号），再回来添加。",
            '宽带管家', 'OK', 'Warning') | Out-Null
        return $null
    }
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = '添加宽带'; $dlg.ClientSize = New-Object Drawing.Size(400, 218)
    $dlg.StartPosition = 'CenterParent'; $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Font = New-Object Drawing.Font('Microsoft YaHei UI', 9)

    $l1 = New-Object Windows.Forms.Label; $l1.Text = '系统里的连接：'; $l1.Location = New-Object Drawing.Point(16, 20); $l1.AutoSize = $true
    $cb = New-Object Windows.Forms.ComboBox
    $cb.Location = New-Object Drawing.Point(126, 17); $cb.Width = 254; $cb.DropDownStyle = 'DropDownList'
    foreach ($n in $names) { [void]$cb.Items.Add($n) }
    $cb.SelectedIndex = 0

    $l2 = New-Object Windows.Forms.Label; $l2.Text = '显示名（可选）：'; $l2.Location = New-Object Drawing.Point(16, 58); $l2.AutoSize = $true
    $tbLabel = New-Object Windows.Forms.TextBox; $tbLabel.Location = New-Object Drawing.Point(126, 55); $tbLabel.Width = 254
    $tbLabel.Text = $names[0]

    $l3 = New-Object Windows.Forms.Label; $l3.Text = '宽带账号：'; $l3.Location = New-Object Drawing.Point(16, 96); $l3.AutoSize = $true
    $tbUser = New-Object Windows.Forms.TextBox; $tbUser.Location = New-Object Drawing.Point(126, 93); $tbUser.Width = 254

    $l4 = New-Object Windows.Forms.Label; $l4.Text = '宽带密码：'; $l4.Location = New-Object Drawing.Point(16, 134); $l4.AutoSize = $true
    $tbPass = New-Object Windows.Forms.TextBox
    $tbPass.Location = New-Object Drawing.Point(126, 131); $tbPass.Width = 254; $tbPass.UseSystemPasswordChar = $true

    # 提示可以留空。很多机器上 Windows 自己早就存过这份密码了（拨号窗口里勾过
    # 「保存密码」），这种情况下留空照样能连上，不必逼用户再去翻运营商的短信。
    $l5 = New-Object Windows.Forms.Label
    $l5.Text = '留空 = 先用系统里保存的那份账号密码试'
    $l5.Location = New-Object Drawing.Point(126, 155); $l5.Width = 254; $l5.Height = 16
    $l5.ForeColor = [Drawing.Color]::FromArgb(120, 120, 120)

    $btnOk = New-Object Windows.Forms.Button; $btnOk.Text = '添加'; $btnOk.Location = New-Object Drawing.Point(206, 172); $btnOk.Size = New-Object Drawing.Size(84, 30); $btnOk.DialogResult = 'OK'
    $btnNo = New-Object Windows.Forms.Button; $btnNo.Text = '取消'; $btnNo.Location = New-Object Drawing.Point(296, 172); $btnNo.Size = New-Object Drawing.Size(84, 30); $btnNo.DialogResult = 'Cancel'
    $dlg.AcceptButton = $btnOk; $dlg.CancelButton = $btnNo

    $cb.Add_SelectedIndexChanged({ if ($tbLabel.Text -eq '' -or $names -contains $tbLabel.Text) { $tbLabel.Text = [string]$cb.SelectedItem } })

    $dlg.Controls.AddRange(@($l1, $cb, $l2, $tbLabel, $l3, $tbUser, $l4, $tbPass, $l5, $btnOk, $btnNo))
    if ($dlg.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $dlg.Dispose(); return $null }
    $res = [pscustomobject]@{
        Name  = [string]$cb.SelectedItem
        Label = $(if ([string]::IsNullOrWhiteSpace($tbLabel.Text)) { [string]$cb.SelectedItem } else { $tbLabel.Text.Trim() })
        User  = $tbUser.Text.Trim()
        Pass  = $tbPass.Text
    }
    $dlg.Dispose()
    return $res
}

function Show-CredDialog {
    param([string]$CurrentAccount)
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = '改账号密码'; $dlg.ClientSize = New-Object Drawing.Size(400, 140)
    $dlg.StartPosition = 'CenterParent'; $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.Font = New-Object Drawing.Font('Microsoft YaHei UI', 9)

    $l3 = New-Object Windows.Forms.Label; $l3.Text = '宽带账号：'; $l3.Location = New-Object Drawing.Point(16, 24); $l3.AutoSize = $true
    $tbUser = New-Object Windows.Forms.TextBox; $tbUser.Location = New-Object Drawing.Point(126, 21); $tbUser.Width = 254; $tbUser.Text = $CurrentAccount

    $l4 = New-Object Windows.Forms.Label; $l4.Text = '宽带密码：'; $l4.Location = New-Object Drawing.Point(16, 62); $l4.AutoSize = $true
    $tbPass = New-Object Windows.Forms.TextBox
    $tbPass.Location = New-Object Drawing.Point(126, 59); $tbPass.Width = 254; $tbPass.UseSystemPasswordChar = $true

    $btnOk = New-Object Windows.Forms.Button; $btnOk.Text = '保存'; $btnOk.Location = New-Object Drawing.Point(206, 98); $btnOk.Size = New-Object Drawing.Size(84, 30); $btnOk.DialogResult = 'OK'
    $btnNo = New-Object Windows.Forms.Button; $btnNo.Text = '取消'; $btnNo.Location = New-Object Drawing.Point(296, 98); $btnNo.Size = New-Object Drawing.Size(84, 30); $btnNo.DialogResult = 'Cancel'
    $dlg.AcceptButton = $btnOk; $dlg.CancelButton = $btnNo

    $dlg.Controls.AddRange(@($l3, $tbUser, $l4, $tbPass, $btnOk, $btnNo))
    if ($dlg.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { $dlg.Dispose(); return $null }
    $res = [pscustomobject]@{ User = $tbUser.Text.Trim(); Pass = $tbPass.Text }
    $dlg.Dispose()
    return $res
}

# ------------------------------------------------------------------ 事件
# 勾选框 = 这条宽带要不要开机自动连接
$lv.Add_ItemCheck({
    param($sender, $e)
    if ($script:SuppressCheck) { return }
    $name = [string]$lv.Items[$e.Index].Tag
    $want = ($e.NewValue -eq [Windows.Forms.CheckState]::Checked)
    $lblStatus.Text = $(if ($want) { "正在为「$name」打开开机自启…" } else { "正在关闭「$name」的开机自启…" })
    $form.Refresh()
    $arg = $(if ($want) { '-AutoOn' } else { '-AutoOff' })
    $rc = (Invoke-Main -MainArgs @($arg, $name)).Code
    if ($rc -ne 0) {
        # 失败就把勾选状态改回去，不让界面说谎
        $script:SuppressCheck = $true
        $lv.Items[$e.Index].Checked = ($e.CurrentValue -eq [Windows.Forms.CheckState]::Checked)
        $script:SuppressCheck = $false
        $lblStatus.Text = "操作失败，详情看日志：$LogFile"
    } else {
        $lblStatus.Text = $(if ($want) { "已开启：「$name」会在登录后自动连接" } else { "已关闭：「$name」不再自动连接" })
    }
})

$btnAdd.Add_Click({
    $d = Show-AddDialog
    if (-not $d) { return }
    $a = @('-AddProfile', $d.Name, '-ProfileLabel', $d.Label)
    if ($d.User) { $a += @('-Account', $d.User) }
    if ($d.Pass) { $a += @('-Password', $d.Pass) }
    $a += @('-AutoStart')      # 新加的默认就开自启：用户加它就是为了自动连
    $rc = (Invoke-Main -MainArgs $a).Code
    if ($rc -ne 0) {
        [Windows.Forms.MessageBox]::Show((Get-FailureMessage "添加「$($d.Label)」"), '宽带管家', 'OK', 'Error') | Out-Null
        $lblStatus.Text = "添加失败：配置没保存下来，看弹窗里的原因"
    } else {
        Update-List
        $lblStatus.Text = "已添加「$($d.Label)」，并打开了开机自启。"
    }
})

$btnDel.Add_Click({
    $n = Get-SelectedName
    if (-not $n) { return }
    if ([Windows.Forms.MessageBox]::Show("确定要从管家列表里删除「$n」吗？`r`n`r`n（只是不再管它，系统里的那个宽带连接不会被删掉）",
            '宽带管家', 'YesNo', 'Question') -ne [Windows.Forms.DialogResult]::Yes) { return }
    if ((Invoke-Main -MainArgs @('-RemoveProfile', $n)).Code -eq 0) {
        Update-List
        $lblStatus.Text = "已删除「$n」。"
    } else {
        $lblStatus.Text = "删除失败，详情看日志：$LogFile"
    }
})

$btnUp.Add_Click({
    $n = Get-SelectedName
    if (-not $n) { return }
    [void](Invoke-Main -MainArgs @('-MoveUp', $n))
    Update-List
})

$btnDown.Add_Click({
    $n = Get-SelectedName
    if (-not $n) { return }
    [void](Invoke-Main -MainArgs @('-MoveDown', $n))
    Update-List
})

$btnCred.Add_Click({
    $n = Get-SelectedName
    if (-not $n) { return }
    $cur = ''
    foreach ($p in (Get-Profiles)) { if ([string]$p.name -eq $n) { $cur = [string]$p.account } }
    $d = Show-CredDialog -CurrentAccount $cur
    if (-not $d) { return }
    $a = @('-SetProfile', $n)
    if ($d.User) { $a += @('-Account', $d.User) }
    if ($d.Pass) { $a += @('-Password', $d.Pass) }
    if ((Invoke-Main -MainArgs $a).Code -eq 0) {
        Update-List
        $lblStatus.Text = '账号密码已更新。'
    } else {
        $lblStatus.Text = (Get-FailureMessage '更新账号密码').Replace("`r`n", ' ')
    }
})

$script:ConnProc = $null

function Start-Connect {
    # 连接要十几秒甚至更久，必须放后台跑，否则窗口会整个卡死
    if ($script:ConnProc -and -not $script:ConnProc.HasExited) { return }
    $btnConnect.Enabled = $false
    $lblStatus.Text = '正在连接…（按顺序一条条试过去，可能要等十几秒）'
    $form.Refresh()
    # 这里刻意不传 -FallbackToUi：界面本身就是「看得见的界面」，
    # 再让主脚本去弹系统拨号窗口，就会「窗口开着 → 自动连接 → 失败 → 又弹窗口」
    # 无限套娃。连接结果由下面的定时器报回状态栏。
    $script:ConnProc = Start-MainAsync -MainArgs @('-Connect')
    if ($script:ConnProc) {
        $script:ConnTimer.Start()
    } else {
        $btnConnect.Enabled = $true
        $lblStatus.Text = '启动连接进程失败。'
    }
}

# 后台那个连接进程一结束，就把结果报回界面上
$script:ConnTimer = New-Object Windows.Forms.Timer
$script:ConnTimer.Interval = 500
$script:ConnTimer.Add_Tick({
    if (-not $script:ConnProc) { $script:ConnTimer.Stop(); return }
    if (-not $script:ConnProc.HasExited) { return }
    $rc = $script:ConnProc.ExitCode
    $script:ConnProc = $null
    $script:ConnTimer.Stop()
    $btnConnect.Enabled = $true
    switch ($rc) {
        0       { $lblStatus.Text = '已连接。' }
        1       { $lblStatus.Text = "没连上。如果还没填账号密码，点「改账号密码」补上；详情看日志：$LogFile" }
        2       { $lblStatus.Text = '还没有配置任何宽带，先点「添加宽带」。' }
        default { $lblStatus.Text = "脚本以退出码 $rc 结束，详情看日志：$LogFile" }
    }
    Update-List
})

$btnConnect.Add_Click({ Start-Connect })

$btnLog.Add_Click({
    if (Test-Path -LiteralPath $LogFile) {
        Start-Process notepad.exe -ArgumentList ('"' + $LogFile + '"')
    } else {
        [Windows.Forms.MessageBox]::Show("还没有日志文件：`r`n$LogFile", '宽带管家', 'OK', 'Information') | Out-Null
    }
})

$btnClose.Add_Click({ $form.Close() })

# 「极速启动」开关。勾上 = 注册开机计划任务，取消 = 注销它。
# 任务是以「当前用户登录时触发」注册的，标准权限就够，正常情况下不会弹 UAC。
# 唯一的例外：这台机器上以前用管理员身份建过同名任务 —— 那种任务当前用户既删不掉
# 也改不动，这时才退回「用管理员再跑一次」（会弹一次 UAC）。
# 做完重新查一遍真实状态再回写勾选框 —— 界面不能显示得跟系统里实际不一样。
$script:SuppressFast = $false
$cbFast.Add_Click({
    if ($script:SuppressFast) { return }
    $want = $cbFast.Checked
    $script:SuppressFast = $true
    $cbFast.Enabled      = $false
    if ($want) { $lblStatus.Text = '状态：正在开启极速启动…' }
    else       { $lblStatus.Text = '状态：正在取消极速启动…' }
    [Windows.Forms.Application]::DoEvents()
    if ($want) { $mainArgs = @('-FastStartOn') } else { $mainArgs = @('-FastStartOff') }
    $code = (Invoke-Main -MainArgs $mainArgs -Capture).Code
    if ($code -ne 0) {
        $lblStatus.Text = '状态：这一步要管理员权限，请在弹窗上点「是」…'
        [Windows.Forms.Application]::DoEvents()
        $code = Invoke-Elevated -MainArgs $mainArgs
    }
    $state = Get-FastStartState
    $cbFast.Checked = ($state -eq 'on')
    $cbFast.Enabled = $true
    $script:SuppressFast = $false
    if ($code -eq 0) {
        if ($state -eq 'on') { $lblStatus.Text = '状态：极速启动已打开，登录后立刻拨号' }
        else                 { $lblStatus.Text = '状态：极速启动已关闭' }
    } else {
        $lblStatus.Text = '状态：没能改成极速启动，详情看日志：' + $LogFile
    }
})

# 「掉线自动重连」开关。它注册的是当前用户的计划任务，不需要管理员，所以这里不弹 UAC
# （这也是它和上面「极速启动」最大的区别）。开关状态以计划任务是否存在为准，
# 做完照样回读一遍真实状态，别让勾选框说假话。
$script:SuppressReconn = $false
$cbReconn.Add_Click({
    if ($script:SuppressReconn) { return }
    $want = $cbReconn.Checked
    $script:SuppressReconn = $true
    $cbReconn.Enabled      = $false
    if ($want) { $lblStatus.Text = '状态：正在开启掉线自动重连…' }
    else       { $lblStatus.Text = '状态：正在取消掉线自动重连…' }
    [Windows.Forms.Application]::DoEvents()
    if ($want) { $r = Invoke-Main -MainArgs @('-ReconnectOn')  -Capture }
    else       { $r = Invoke-Main -MainArgs @('-ReconnectOff') -Capture }
    $state = Get-ReconnectState
    $cbReconn.Checked = ($state -eq 'on')
    $cbReconn.Enabled = $true
    $script:SuppressReconn = $false
    if ($r.Code -eq 0) {
        if ($state -eq 'on') { $lblStatus.Text = '状态：掉线自动重连已打开，掉线或睡眠唤醒后几秒就会自动接回来' }
        else                 { $lblStatus.Text = '状态：掉线自动重连已关闭' }
    } else {
        $lblStatus.Text = '状态：没能改掉线自动重连，详情看日志：' + $LogFile
    }
})

# 卸载：确认后用管理员跑安装目录里的 uninstall.ps1（它会一并注销开机计划任务）
$btnUninstall.Add_Click({
    $msg = '确定要卸载「宽带管家」吗？' + "`r`n`r`n" +
           '会删掉：桌面和开始菜单的图标、开机启动项、极速启动和掉线重连的计划任务、程序文件。' + "`r`n`r`n" +
           '会保留：你已经保存的宽带账号密码（以后重装不用重填）。' + "`r`n" +
           '想连密码一起删，卸载完手动删掉这个文件夹：' + "`r`n" +
           (Join-Path $env:LOCALAPPDATA 'SchoolBroadband')
    $r = [Windows.Forms.MessageBox]::Show($msg, '卸载 宽带管家', 'YesNo', 'Warning')
    if ($r -ne 'Yes') { return }
    $un = Join-Path $PSScriptRoot 'uninstall.ps1'
    if (-not (Test-Path -LiteralPath $un)) {
        [Windows.Forms.MessageBox]::Show("找不到卸载程序：`r`n$un", '宽带管家', 'OK', 'Error') | Out-Null
        return
    }
    $exe  = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $line = '-NoProfile -ExecutionPolicy Bypass -File "' + $un + '" -Silent -Pause'
    try {
        Start-Process -FilePath $exe -ArgumentList $line -Verb RunAs -ErrorAction Stop | Out-Null
        $form.Close()
    } catch {
        [Windows.Forms.MessageBox]::Show('卸载需要管理员权限，刚才的确认被取消了。', '宽带管家', 'OK', 'Warning') | Out-Null
    }
})

$form.Controls.AddRange(@($lblTitle, $lblDesc, $lv,
                          $btnAdd, $btnDel, $btnUp, $btnDown, $btnCred,
                          $btnConnect, $btnUninstall, $lblStatus, $cbFast, $cbReconn, $btnLog, $btnClose))
$form.AcceptButton = $btnConnect
$form.CancelButton = $btnClose

# 打开窗口时先把「极速启动」的真实状态读出来（读状态不需要管理员）
$script:SuppressFast = $true
$cbFast.Checked = ((Get-FastStartState) -eq 'on')
$script:SuppressFast = $false

# 「掉线自动重连」同理，也先读真实状态再显示
$script:SuppressReconn = $true
$cbReconn.Checked = ((Get-ReconnectState) -eq 'on')
$script:SuppressReconn = $false

# 打开窗口只报当前状态，【不】自动去连 —— 双击的第一诉求是「窗口马上出来」，
# 想连的时候点「立即连接」。开机自连和掉线重连都不经过这个界面（那两条走的是
# VBS + 计划任务），所以去掉自动连接不影响它们。
$form.Add_Shown({
    if (Test-ConnectedNow) {
        $lblStatus.Text = '状态：已连接'
    } else {
        $lblStatus.Text = '状态：未连接（要连就点左边的「立即连接」）'
    }
})

Update-List
[void]$form.ShowDialog()
$script:ConnTimer.Dispose()
$form.Dispose()
